import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, RotateCcw, SkipForward, Subtitles, Film, Upload } from 'lucide-react';
import { sounds } from '../audio/SoundManager';

interface DisasterCinematicModalProps {
  onComplete: () => void;
}

interface SubtitleCue {
  start: number;
  end: number;
  speaker: string;
  speakerColor: string;
  text: string;
}

const SUBTITLE_CUES: SubtitleCue[] = [
  // Scene 01 — A Normal Mission (0-8s)
  {
    start: 0.4,
    end: 4.2,
    speaker: 'HAZALOOM',
    speakerColor: 'text-amber-400',
    text: "I still can't believe we're actually here.",
  },
  {
    start: 4.2,
    end: 8.0,
    speaker: 'SAMANTHA',
    speakerColor: 'text-purple-300',
    text: "Enjoy the view. We're about to make history.",
  },
  // Scene 02 — The Warning (8-16s)
  {
    start: 8.2,
    end: 12.1,
    speaker: 'HEDEYA',
    speakerColor: 'text-sky-300',
    text: "Wait... I'm checking an abnormal pressure reading.",
  },
  {
    start: 12.1,
    end: 16.0,
    speaker: 'SAMANTHA',
    speakerColor: 'text-purple-300',
    text: 'What? That system was cleared before launch!',
  },
  // Scene 03 — The Explosion (16-25s)
  {
    start: 16.2,
    end: 20.1,
    speaker: 'HAZALOOM',
    speakerColor: 'text-amber-400',
    text: 'WHAT WAS THAT?!',
  },
  {
    start: 20.1,
    end: 25.0,
    speaker: 'SAMANTHA',
    speakerColor: 'text-red-400',
    text: 'EMERGENCY! Everyone, hold on tight!',
  },
  // Scene 04 — The Silence (25-36s)
  {
    start: 25.5,
    end: 29.0,
    speaker: 'HEDEYA',
    speakerColor: 'text-sky-300',
    text: 'Everyone... answer me. Is everyone okay?',
  },
  {
    start: 29.0,
    end: 32.5,
    speaker: 'SAMANTHA',
    speakerColor: 'text-purple-300',
    text: "We're alive. But our main ship systems are broken.",
  },
  {
    start: 32.5,
    end: 36.0,
    speaker: 'HAZALOOM',
    speakerColor: 'text-amber-400',
    text: "Does that mean... we can't go home?",
  },
  // Scene 05 — The New Mission (36-49s)
  {
    start: 36.5,
    end: 43.2,
    speaker: 'MISSION CONTROL',
    speakerColor: 'text-emerald-300',
    text: 'Crew, we checked the damage. Your old return plan will not work.',
  },
  {
    start: 43.2,
    end: 49.0,
    speaker: 'SAMANTHA',
    speakerColor: 'text-purple-300',
    text: "Then we'll find another way.",
  },
];

const SINGLE_VIDEO_PATH = '/assets/cinematic/cutscene.mp4';
const SCENE_CLIP_PATHS = [
  '/assets/cinematic/scene_01.mp4',
  '/assets/cinematic/scene_02.mp4',
  '/assets/cinematic/scene_03.mp4',
  '/assets/cinematic/scene_04.mp4',
  '/assets/cinematic/scene_05.mp4',
];

// Remembers a locally loaded video across replays in the current browser session
let sessionCustomVideoUrl: string | null = null;

async function checkVideoExists(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { method: 'HEAD' });
    const contentType = res.headers.get('content-type') || '';
    return res.ok && contentType.startsWith('video/');
  } catch {
    return false;
  }
}

export const DisasterCinematicModal: React.FC<DisasterCinematicModalProps> = ({ onComplete }) => {
  const [playlist, setPlaylist] = useState<string[] | null>(
    sessionCustomVideoUrl ? [sessionCustomVideoUrl] : null
  );
  const [isCheckingVideo, setIsCheckingVideo] = useState(!sessionCustomVideoUrl);
  const [clipIndex, setClipIndex] = useState(0);
  const [clipOffsets, setClipOffsets] = useState<number[]>([0]);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [subtitlesOn, setSubtitlesOn] = useState(true);
  const [isMuted, setIsMuted] = useState(sounds.getMuted());
  const [videoLoadError, setVideoLoadError] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  // Discover real video file(s) in /assets/cinematic/
  useEffect(() => {
    if (sessionCustomVideoUrl) {
      setPlaylist([sessionCustomVideoUrl]);
      setIsCheckingVideo(false);
      return;
    }

    let cancelled = false;
    (async () => {
      setIsCheckingVideo(true);
      if (await checkVideoExists(SINGLE_VIDEO_PATH)) {
        if (!cancelled) {
          setPlaylist([SINGLE_VIDEO_PATH]);
          setIsCheckingVideo(false);
        }
        return;
      }

      const foundClips: string[] = [];
      for (const clipPath of SCENE_CLIP_PATHS) {
        if (await checkVideoExists(clipPath)) {
          foundClips.push(clipPath);
        }
      }

      if (!cancelled) {
        setPlaylist(foundClips.length > 0 ? foundClips : []);
        setIsCheckingVideo(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const currentClipSrc = playlist && playlist[clipIndex] ? playlist[clipIndex] : null;
  const cumulativeOffset = clipOffsets[clipIndex] ?? 0;
  const totalElapsedSeconds = cumulativeOffset + currentTime;
  const activeSubtitle = SUBTITLE_CUES.find(
    (cue) => totalElapsedSeconds >= cue.start && totalElapsedSeconds < cue.end
  );

  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (!el) return;
    setDuration(Number.isFinite(el.duration) ? el.duration : 0);
    el.muted = isMuted;
    el.play().catch(() => {
      // If autoplay with audio is blocked by browser, retry muted cleanly
      el.muted = true;
      setIsMuted(true);
      el.play().catch(() => undefined);
    });
  };

  const handleVideoEnded = () => {
    if (playlist && clipIndex < playlist.length - 1) {
      const finishedDuration = videoRef.current?.duration || duration || 0;
      setClipOffsets((prev) => {
        const next = [...prev];
        next[clipIndex + 1] = (next[clipIndex] ?? 0) + finishedDuration;
        return next;
      });
      setCurrentTime(0);
      setClipIndex((prev) => prev + 1);
    } else {
      onCompleteRef.current();
    }
  };

  const handleToggleSound = () => {
    const nextMuted = sounds.toggleMute();
    setIsMuted(nextMuted);
    if (videoRef.current) {
      videoRef.current.muted = nextMuted;
    }
  };

  const handleReplay = () => {
    setVideoLoadError(false);
    setClipOffsets([0]);
    setCurrentTime(0);
    if (clipIndex !== 0) {
      setClipIndex(0);
    } else if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => undefined);
    }
  };

  const handlePickLocalVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (sessionCustomVideoUrl) {
      URL.revokeObjectURL(sessionCustomVideoUrl);
    }
    const url = URL.createObjectURL(file);
    sessionCustomVideoUrl = url;
    setVideoLoadError(false);
    setClipOffsets([0]);
    setClipIndex(0);
    setCurrentTime(0);
    setPlaylist([url]);
  };

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-between bg-black text-white select-none overflow-hidden"
      role="dialog"
      aria-label="Story Cutscene: The Moment Everything Changed"
    >
      {/* Hidden local file picker for previewing an AI-generated MP4/WebM */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/*"
        onChange={handlePickLocalVideo}
        className="hidden"
      />

      {/* Video Stage */}
      <div className="absolute inset-0 bg-black flex items-center justify-center">
        {currentClipSrc && !videoLoadError && (
          <video
            ref={videoRef}
            key={currentClipSrc}
            src={currentClipSrc}
            playsInline
            autoPlay
            muted={isMuted}
            onLoadedMetadata={handleLoadedMetadata}
            onTimeUpdate={() => setCurrentTime(videoRef.current?.currentTime || 0)}
            onEnded={handleVideoEnded}
            onError={() => setVideoLoadError(true)}
            className="w-full h-full object-contain bg-black"
          />
        )}

        {/* Top & bottom subtle gradient bars for control & subtitle legibility */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/85 to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-black/90 to-transparent" />
      </div>

      {/* Top Cinema Header & Controls */}
      <div className="relative z-20 flex flex-wrap items-center justify-between gap-3 px-4 sm:px-8 pt-4 sm:pt-6">
        <div className="flex flex-col gap-0.5">
          <span className="font-mono-hud text-xs font-bold tracking-widest text-amber-400 uppercase">
            THE MOMENT EVERYTHING CHANGED
          </span>
          {playlist && playlist.length > 1 && (
            <span className="font-title text-xs font-bold tracking-wide text-slate-300 uppercase">
              Clip {clipIndex + 1} of {playlist.length}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/85 hover:bg-slate-800 border border-slate-700 text-xs font-mono-hud font-bold text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-amber-400" />
            <span>Load Video</span>
          </button>

          {currentClipSrc && !videoLoadError && (
            <>
              <button
                onClick={() => setSubtitlesOn((prev) => !prev)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/85 hover:bg-slate-800 border border-slate-700 text-xs font-mono-hud font-bold text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Subtitles className="w-4 h-4 text-amber-400" />
                <span>{subtitlesOn ? 'Subtitles: On' : 'Subtitles: Off'}</span>
              </button>

              <button
                onClick={handleToggleSound}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/85 hover:bg-slate-800 border border-slate-700 text-xs font-mono-hud font-bold text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-red-400" />
                ) : (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                )}
                <span>{isMuted ? 'Sound: Off' : 'Sound: On'}</span>
              </button>

              <button
                onClick={handleReplay}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/85 hover:bg-slate-800 border border-slate-700 text-xs font-mono-hud font-bold text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
                <span>Replay</span>
              </button>
            </>
          )}

          <button
            onClick={onComplete}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-mono-hud font-bold uppercase tracking-wider transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-lg"
          >
            <span>Skip</span>
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Missing / Loading Video Prompt (when no MP4 file is installed yet) */}
      {!isCheckingVideo && (!currentClipSrc || videoLoadError) && (
        <div className="relative z-20 my-auto mx-auto w-full max-w-xl px-4">
          <div className="rounded-2xl bg-slate-950/95 border border-slate-700 p-6 sm:p-8 text-center shadow-2xl">
            <div className="mx-auto mb-4 w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Film className="w-6 h-6" />
            </div>
            <h2 className="font-title text-xl sm:text-2xl font-bold uppercase text-white">
              Add Your AI Cutscene Video
            </h2>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              No video file is added yet. Save your exported <code className="text-amber-300">.mp4</code> cutscene at{' '}
              <code className="text-amber-300">public/assets/cinematic/cutscene.mp4</code> (or{' '}
              <code className="text-amber-300">scene_01.mp4</code> to <code className="text-amber-300">scene_05.mp4</code>), or pick a video from your computer right now.
            </p>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full sm:w-auto py-3 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono-hud text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Choose Video File (.mp4)</span>
              </button>

              <button
                onClick={onComplete}
                className="w-full sm:w-auto py-3 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-mono-hud text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Skip to Mission 1</span>
                <SkipForward className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Subtitles & Video Progress Bar */}
      <div className="relative z-20 w-full max-w-4xl mx-auto px-4 sm:px-8 pb-5 sm:pb-7 flex flex-col gap-3">
        {currentClipSrc && !videoLoadError && subtitlesOn && activeSubtitle && (
          <div className="mx-auto w-full max-w-2xl rounded-xl bg-black/85 border border-slate-700/80 px-5 py-3 text-center shadow-2xl backdrop-blur-md">
            <div className={`font-mono-hud text-xs font-bold tracking-widest uppercase mb-1 ${activeSubtitle.speakerColor}`}>
              {activeSubtitle.speaker}
            </div>
            <p className="text-base sm:text-lg font-semibold text-white leading-snug">
              "{activeSubtitle.text}"
            </p>
          </div>
        )}

        {currentClipSrc && !videoLoadError && (
          <div className="flex items-center gap-3">
            <span className="font-mono-hud text-[11px] text-slate-300 w-10 text-right tabular-nums">
              {Math.floor(currentTime)}s
            </span>
            <div className="flex-1 h-1.5 rounded bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-100"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="font-mono-hud text-[11px] text-slate-400 w-10 tabular-nums">
              {Math.floor(duration)}s
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
