import React, { useState } from 'react';
import { Play, BookOpen, Compass, Info, Radio, Sparkles, Download, Lock, CheckCircle2, Users, Home } from 'lucide-react';
import { sounds } from '../audio/SoundManager';
import { MissionId } from '../types/game';
import { CrewMember } from '../data/CrewData';

interface MainMenuProps {
  selectedMission: MissionId;
  completedMissions: MissionId[];
  selectedCrew?: CrewMember | null;
  onSelectMission: (mission: MissionId) => void;
  onStartGame: () => void;
  onOpenFieldGuide: () => void;
  onChangeCrew?: () => void;
  onBackToHome?: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  selectedMission,
  completedMissions,
  selectedCrew,
  onSelectMission,
  onStartGame,
  onOpenFieldGuide,
  onChangeCrew,
  onBackToHome,
}) => {
  const [showBriefing, setShowBriefing] = useState(false);
  const [showControls, setShowControls] = useState(false);

  const isMission1Done = completedMissions.includes('mission_1');
  const isMission2Done = completedMissions.includes('mission_2');
  const isMission3Done = completedMissions.includes('mission_3');

  const isMission2Unlocked = isMission1Done;
  const isMission3Unlocked = isMission2Done;

  const isSelectedUnlocked =
    selectedMission === 'mission_1' ||
    (selectedMission === 'mission_2' && isMission2Unlocked) ||
    (selectedMission === 'mission_3' && isMission3Unlocked);

  const handleStart = () => {
    if (!isSelectedUnlocked) return;
    sounds.playObjectiveStinger();
    onStartGame();
  };

  const bgImage =
    selectedMission === 'mission_3'
      ? '/assets/nasa/sample_core_tube.jpg'
      : selectedMission === 'mission_2'
      ? '/assets/nasa/kodiak_layered_rock.jpg'
      : '/assets/nasa/jezero_crater.jpg';

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-6 sm:p-12 overflow-y-auto select-none bg-black">
      {/* Background NASA Mars Image */}
      <div className="absolute inset-0 z-0 transition-all duration-700">
        <img
          src={bgImage}
          alt="Mars Surface"
          className="w-full h-full object-cover object-center filter brightness-40 contrast-125 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0c0706] via-[#0c0706]/75 to-[#0c0706]/45" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(12,7,6,0.85)_100%)]" />
      </div>

      {/* Top Bar Header */}
      <div className="relative z-10 flex items-center justify-between border-b border-orange-950/60 pb-4">
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
          <span className="font-mono-hud text-xs sm:text-sm font-bold tracking-widest text-orange-400 uppercase">
            MARS EXPLORER // JEZERO CRATER
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-orange-950/40 border border-orange-500/30 text-xs font-mono-hud text-orange-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>REAL NASA MARS ADVENTURE</span>
        </div>
      </div>

      {/* Center Branding & Mission Selector */}
      <div className="relative z-10 my-auto flex flex-col items-center text-center max-w-5xl mx-auto py-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-950/60 border border-red-500/50 text-red-300 text-xs font-mono-hud font-bold uppercase mb-3 shadow-lg">
          {selectedCrew?.image ? (
            <img
              src={selectedCrew.image}
              alt={selectedCrew.name}
              className="w-5 h-5 rounded-full object-contain bg-black/50"
              style={{ imageRendering: 'pixelated' }}
            />
          ) : (
            <Radio className="w-3.5 h-3.5 animate-pulse text-red-400" />
          )}
          <span>
            {selectedCrew
              ? `CREW LEADER: ${selectedCrew.name.toUpperCase()} · ${selectedCrew.role.toUpperCase()}`
              : 'PLAY WITH HAZALOOM, HEDEYA & SAMANTHA'}
          </span>
        </div>

        <h1 className="font-title text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white uppercase drop-shadow-2xl">
          MARS MISSION
        </h1>
        <p className="font-mono-hud text-xs sm:text-sm text-slate-300 mt-2 max-w-xl">
          Finish each mission to unlock the next one! Drive your Mars rover, learn cool NASA space facts, and fly home!
        </p>

        {/* MISSION SELECTOR CARDS (SEQUENTIAL LOCKING) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 w-full max-w-4xl mt-6">
          {/* Mission 1 Card (Always Unlocked) */}
          <button
            onClick={() => {
              onSelectMission('mission_1');
              sounds.playPickup();
            }}
            className={`p-4 rounded-2xl text-left border transition-all cursor-pointer ${
              selectedMission === 'mission_1'
                ? 'bg-amber-500/20 border-amber-400 shadow-xl shadow-amber-500/10'
                : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono-hud font-bold text-amber-400 uppercase tracking-wider">
                MISSION 1
              </span>
              {isMission1Done ? (
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono-hud font-bold">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>DONE!</span>
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono-hud font-bold">
                  OPEN
                </span>
              )}
            </div>
            <div className="font-title text-base sm:text-lg font-bold text-white uppercase">
              1: Mission Home Begins
            </div>
            <p className="font-mono-hud text-xs text-slate-300 mt-1">
              Check your ship after landing, survive the sudden emergency, fix the radio tower, and beat the dust storm!
            </p>
          </button>

          {/* Mission 2 Card (Locked until Mission 1 is done) */}
          <button
            disabled={!isMission2Unlocked}
            onClick={() => {
              if (!isMission2Unlocked) return;
              onSelectMission('mission_2');
              sounds.playPickup();
            }}
            className={`p-4 rounded-2xl text-left border transition-all ${
              !isMission2Unlocked
                ? 'bg-slate-950/70 border-slate-800/80 opacity-65 cursor-not-allowed'
                : selectedMission === 'mission_2'
                ? 'bg-cyan-500/20 border-cyan-400 shadow-xl shadow-cyan-500/10 cursor-pointer'
                : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700 cursor-pointer'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono-hud font-bold text-cyan-400 uppercase tracking-wider">
                MISSION 2
              </span>
              {!isMission2Unlocked ? (
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[9px] font-mono-hud font-bold">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span>LOCKED</span>
                </span>
              ) : isMission2Done ? (
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono-hud font-bold">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>DONE!</span>
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[9px] font-mono-hud font-bold">
                  UNLOCKED!
                </span>
              )}
            </div>
            <div className="font-title text-base sm:text-lg font-bold text-white uppercase">
              2: Underground Cave
            </div>
            <p className="font-mono-hud text-xs text-slate-300 mt-1">
              {!isMission2Unlocked
                ? 'Finish Mission 1 first to unlock this adventure!'
                : 'Drop two ground sensors, drive inside a dark lava cave, and drill a Mars rock!'}
            </p>
          </button>

          {/* Mission 3 Card (Locked until Mission 2 is done) */}
          <button
            disabled={!isMission3Unlocked}
            onClick={() => {
              if (!isMission3Unlocked) return;
              onSelectMission('mission_3');
              sounds.playPickup();
            }}
            className={`p-4 rounded-2xl text-left border transition-all ${
              !isMission3Unlocked
                ? 'bg-slate-950/70 border-slate-800/80 opacity-65 cursor-not-allowed'
                : selectedMission === 'mission_3'
                ? 'bg-red-500/20 border-red-400 shadow-xl shadow-red-500/10 cursor-pointer'
                : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700 cursor-pointer'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono-hud font-bold text-red-400 uppercase tracking-wider">
                MISSION 3
              </span>
              {!isMission3Unlocked ? (
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[9px] font-mono-hud font-bold">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span>LOCKED</span>
                </span>
              ) : isMission3Done ? (
                <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-mono-hud font-bold">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>DONE!</span>
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 text-[9px] font-mono-hud font-bold">
                  UNLOCKED!
                </span>
              )}
            </div>
            <div className="font-title text-base sm:text-lg font-bold text-white uppercase">
              3: Rocket Home
            </div>
            <p className="font-mono-hud text-xs text-slate-300 mt-1">
              {!isMission3Unlocked
                ? 'Finish Mission 2 first to unlock the rocket launch!'
                : 'Fix rover switches, dodge dust tornadoes, launch the Mars Rocket, and dock in space!'}
            </p>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 mt-6 w-full max-w-md">
          <button
            disabled={!isSelectedUnlocked}
            onClick={handleStart}
            className={`w-full sm:flex-1 py-4 px-6 rounded-2xl font-mono-hud text-sm font-bold tracking-wider uppercase transition-all shadow-2xl flex items-center justify-center gap-2 ${
              !isSelectedUnlocked
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : selectedMission === 'mission_3'
                ? 'bg-red-500 hover:bg-red-400 text-white cursor-pointer hover:scale-[1.02] active:scale-[0.98]'
                : selectedMission === 'mission_2'
                ? 'bg-cyan-500 hover:bg-cyan-400 text-black cursor-pointer hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-amber-500 hover:bg-amber-400 text-black cursor-pointer hover:scale-[1.02] active:scale-[0.98]'
            }`}
          >
            <Play className="w-5 h-5 fill-current" />
            <span>
              Play {selectedMission === 'mission_3' ? 'Mission 3' : selectedMission === 'mission_2' ? 'Mission 2' : 'Mission 1'}
            </span>
          </button>

          <button
            onClick={onOpenFieldGuide}
            className="w-full sm:w-auto py-4 px-6 rounded-2xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-200 font-mono-hud text-xs font-bold transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>Space Facts Book</span>
          </button>
        </div>

        {/* Secondary Info Toggles */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-6">
          <button
            onClick={() => setShowBriefing(true)}
            className="flex items-center gap-1.5 text-xs font-mono-hud text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
          >
            <Info className="w-3.5 h-3.5" />
            <span>Story</span>
          </button>
          <span className="text-slate-600">|</span>
          <button
            onClick={() => setShowControls(true)}
            className="flex items-center gap-1.5 text-xs font-mono-hud text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>How to Play</span>
          </button>
          {onChangeCrew && (
            <>
              <span className="text-slate-600">|</span>
              <button
                onClick={onChangeCrew}
                className="flex items-center gap-1.5 text-xs font-mono-hud text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Crew</span>
              </button>
            </>
          )}
          {onBackToHome && (
            <>
              <span className="text-slate-600">|</span>
              <button
                onClick={onBackToHome}
                className="flex items-center gap-1.5 text-xs font-mono-hud text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Home</span>
              </button>
            </>
          )}
          <span className="text-slate-600">|</span>
          <a
            href="/mars-mission-game.zip"
            download="mars-mission-game.zip"
            className="flex items-center gap-1.5 text-xs font-mono-hud text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Game ZIP</span>
          </a>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono-hud text-slate-400 border-t border-slate-900 pt-3 gap-2">
        <div>FINISH MISSION 1 TO UNLOCK MISSION 2 AND MISSION 3!</div>
        <div>REAL NASA MARS FACTS INSIDE</div>
      </div>

      {/* Story Modal */}
      {showBriefing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl rounded-2xl bg-slate-950 border border-slate-700 p-6 text-white shadow-2xl max-h-[85vh] overflow-y-auto">
            <h3 className="font-title text-xl font-bold uppercase text-amber-400 mb-3">
              The Mars Story
            </h3>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 mb-3">
              <span className="text-xs font-mono-hud font-bold text-amber-400 uppercase">
                MISSION 1: THE MOMENT EVERYTHING CHANGED
              </span>
              <p className="font-mono-hud text-xs text-slate-200 leading-relaxed mt-1">
                Hazaloom, Hedeya, and Samantha check their Mars ship—when a sudden explosion breaks their return rocket! Hazaloom must grab a spare power part, drive the rover past big rocks, fix the radio tower to call Earth, and race back before a dust storm hits!
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 mb-3">
              <span className="text-xs font-mono-hud font-bold text-cyan-400 uppercase">
                MISSION 2: UNDERGROUND CAVE
              </span>
              <p className="font-mono-hud text-xs text-slate-200 leading-relaxed mt-1">
                Hazaloom, Hedeya, and Samantha place two ground sensors in an old river valley, drive into a dark underground lava cave, drill a Mars rock, and escape when the cave starts shaking!
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 mb-4">
              <span className="text-xs font-mono-hud font-bold text-red-400 uppercase">
                MISSION 3: ROCKET HOME
              </span>
              <p className="font-mono-hud text-xs text-slate-200 leading-relaxed mt-1">
                Hazaloom turns off a broken rover heater, steers past dust tornadoes to the launch pad, flies the two-stage Mars Rocket into space, and docks with the spaceship going home to Earth!
              </p>
            </div>

            <button
              onClick={() => setShowBriefing(false)}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-mono-hud font-bold cursor-pointer"
            >
              Got It!
            </button>
          </div>
        </div>
      )}

      {/* How to Play Modal */}
      {showControls && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-2xl bg-slate-950 border border-slate-700 p-6 text-white shadow-2xl">
            <h3 className="font-title text-xl font-bold uppercase text-amber-400 mb-3">
              How to Play
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono-hud mb-4">
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <div className="text-slate-400">Walk / Drive / Dock:</div>
                <div className="text-amber-300 font-bold">WASD or Arrow Keys</div>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <div className="text-slate-400">Pick Up / Use / Drill:</div>
                <div className="text-amber-300 font-bold">[E] Key</div>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <div className="text-slate-400">Next Message:</div>
                <div className="text-amber-300 font-bold">[SPACE] or [ENTER]</div>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <div className="text-slate-400">Fill Suit Air:</div>
                <div className="text-emerald-400 font-bold">Stand in Green Circle</div>
              </div>
            </div>
            <p className="font-mono-hud text-xs text-slate-300 leading-relaxed mb-4">
              • Follow the yellow diamond on your round map at the bottom left.<br />
              • Watch the top bar for your current goal.<br />
              • Finish Mission 1 to unlock Mission 2, and finish Mission 2 to unlock Mission 3!
            </p>
            <button
              onClick={() => setShowControls(false)}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-mono-hud font-bold cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
