import React from 'react';
import { MissionStats, MissionId } from '../types/game';
import {
  Trophy,
  RotateCcw,
  BookOpen,
  Clock,
  Wind,
  Battery,
  Shield,
  Radio,
  ArrowRight,
  Home,
} from 'lucide-react';
import { sounds } from '../audio/SoundManager';

interface MissionCompleteModalProps {
  stats: MissionStats;
  onReplay: () => void;
  onContinueToMission2?: () => void;
  onContinueToMission3?: () => void;
  onSelectMission?: (mission: MissionId) => void;
  onOpenFieldGuide: () => void;
}

export const MissionCompleteModal: React.FC<MissionCompleteModalProps> = ({
  stats,
  onReplay,
  onContinueToMission2,
  onContinueToMission3,
  onSelectMission,
  onOpenFieldGuide,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const isMission2 = stats.missionId === 'mission_2';
  const isMission3 = stats.missionId === 'mission_3';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-lg animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border-2 border-emerald-500/70 p-6 sm:p-8 text-white shadow-2xl">
        <div className="text-center pb-6 border-b border-slate-800">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 mb-3">
            <Trophy className="w-8 h-8" />
          </div>
          <div className="font-mono-hud text-xs tracking-widest text-emerald-400 font-bold uppercase mb-1">
            GREAT JOB!
          </div>
          <h1 className="font-title text-3xl sm:text-5xl font-black tracking-wider uppercase text-white drop-shadow-md">
            {isMission3 ? 'YOU BEAT THE GAME!' : 'MISSION DONE!'}
          </h1>
          <p className="font-mono-hud text-xs sm:text-sm text-slate-400 mt-1">
            {isMission3
              ? 'Mission 3: Rocket Home'
              : isMission2
              ? 'Mission 2: Underground Cave'
              : 'Mission 1: Fix the Radio'}
          </p>
        </div>

        {/* Simple Story Summary */}
        <div className="my-6 p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60 text-center">
          <div className="flex items-center justify-center gap-2 text-emerald-400 text-xs font-mono-hud font-bold mb-1">
            <Radio className="w-4 h-4 animate-pulse text-emerald-400" />
            <span>
              {isMission3
                ? 'ROCKET DOCKED SAFE IN SPACE!'
                : isMission2
                ? 'MARS ROCK SAVED & MISSION 3 UNLOCKED!'
                : 'RADIO FIXED & MISSION 2 UNLOCKED!'}
            </span>
          </div>
          <p className="font-title text-base sm:text-lg font-bold text-slate-100 tracking-wide italic">
            {isMission3
              ? '“We docked with the spaceship! Time to fly our Mars rock home to Earth!”'
              : isMission2
              ? '“You escaped the shaking cave with Rock Tube #14!”'
              : '“You fixed the radio tower and beat the dust storm! Earth can hear us!”'}
          </p>
          <p className="text-xs font-mono-hud text-slate-300 mt-1">
            {isMission3
              ? 'Hazaloom, Hedeya, and Samantha finished all 3 Mars missions!'
              : isMission2
              ? 'Hazaloom, Hedeya, and Samantha are ready for Mission 3!'
              : 'Hazaloom, Hedeya, and Samantha unlocked Mission 2!'}
          </p>
        </div>

        {/* Simple Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <Clock className="w-4 h-4 text-sky-400" />
              <span>TIME</span>
            </div>
            <div className="font-title text-lg font-bold text-white">
              {formatTime(stats.elapsedSeconds)}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <Wind className="w-4 h-4 text-sky-400" />
              <span>AIR LEFT</span>
            </div>
            <div className="font-title text-lg font-bold text-sky-300">
              {Math.round(stats.finalOxygen)}%
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <Battery className="w-4 h-4 text-amber-400" />
              <span>BATTERY LEFT</span>
            </div>
            <div className="font-title text-lg font-bold text-amber-300">
              {Math.round(stats.finalBattery)}%
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>ROVER HEALTH</span>
            </div>
            <div className="font-title text-lg font-bold text-emerald-300">
              {Math.round(stats.finalCondition)}%
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <Shield className="w-4 h-4 text-red-400" />
              <span>ROCK BUMPS</span>
            </div>
            <div className="font-title text-lg font-bold text-slate-200">
              {stats.rockCollisions} hits
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-400 mb-1">
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>SPACE FACTS</span>
            </div>
            <div className="font-title text-lg font-bold text-purple-300">
              {stats.factsDiscovered} / {stats.totalFacts}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onOpenFieldGuide}
              className="flex-1 sm:flex-initial px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-hud text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Space Facts</span>
            </button>

            {onSelectMission && (
              <button
                onClick={() => onSelectMission(isMission3 ? 'mission_1' : stats.missionId)}
                className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-hud text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
                title="Main Menu"
              >
                <Home className="w-4 h-4" />
                <span>Menu</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onReplay}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-mono-hud text-xs font-bold transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>

            {!isMission2 && !isMission3 && onContinueToMission2 && (
              <button
                onClick={() => {
                  sounds.playObjectiveStinger();
                  onContinueToMission2();
                }}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-mono-hud text-xs font-bold transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.02]"
              >
                <span>Play Mission 2!</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {isMission2 && onContinueToMission3 && (
              <button
                onClick={() => {
                  sounds.playObjectiveStinger();
                  onContinueToMission3();
                }}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-red-500 hover:bg-red-400 text-white font-mono-hud text-xs font-bold transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer hover:scale-[1.02]"
              >
                <span>Play Mission 3!</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {isMission3 && onSelectMission && (
              <button
                onClick={() => {
                  sounds.playObjectiveStinger();
                  onSelectMission('mission_1');
                }}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono-hud text-xs font-bold transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Main Menu</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
