import React from 'react';
import { AlertTriangle, Play, RotateCcw, Radio, ShieldCheck, Wrench, Flame } from 'lucide-react';

interface DamagedShipStatusModalProps {
  onStartMission: () => void;
  onReplayCutscene: () => void;
}

export const DamagedShipStatusModal: React.FC<DamagedShipStatusModalProps> = ({
  onStartMission,
  onReplayCutscene,
}) => {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
      role="dialog"
      aria-label="Damaged Spacecraft Emergency Status"
    >
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-950 border border-red-500/50 text-white shadow-2xl overflow-hidden">
        {/* Top Damaged Ship Visual Header */}
        <div className="relative h-44 sm:h-52 w-full bg-gradient-to-b from-slate-900 to-black overflow-hidden">
          <img
            src="/assets/nasa/jezero_crater.jpg"
            alt="Jezero Crater landing zone on Mars near the damaged spacecraft"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center brightness-50 contrast-125"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
          <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-red-400 font-mono-hud text-xs font-bold uppercase tracking-wider mb-1">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>EMERGENCY SHIP REPORT</span>
              </div>
              <h2 className="font-title text-2xl sm:text-3xl font-black uppercase tracking-wide text-white">
                SHIP DAMAGED — MISSION HOME
              </h2>
            </div>
          </div>
        </div>

        {/* Emergency System Status Grid */}
        <div className="p-5 sm:p-6 flex flex-col gap-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono-hud text-xs">
            <div className="flex items-center justify-between p-3 rounded-xl bg-red-950/35 border border-red-500/40">
              <div className="flex items-center gap-2.5 text-slate-200">
                <Flame className="w-4 h-4 text-red-400 shrink-0" />
                <span>Main Return Rocket</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 font-bold">
                BROKEN
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-red-950/35 border border-red-500/40">
              <div className="flex items-center gap-2.5 text-slate-200">
                <Radio className="w-4 h-4 text-red-400 shrink-0" />
                <span>Earth Radio Tower</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 font-bold">
                OFFLINE
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-amber-950/30 border border-amber-500/40">
              <div className="flex items-center gap-2.5 text-slate-200">
                <Wrench className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Radio Power Part</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                IN ORANGE BOX
              </span>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/40">
              <div className="flex items-center gap-2.5 text-slate-200">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Astronaut Crew</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                3 / 3 SAFE
              </span>
            </div>
          </div>

          <p className="text-sm text-slate-200 leading-relaxed bg-slate-900/80 border border-slate-800 rounded-xl p-4">
            Our old spacecraft cannot fly us back to Earth! First, grab the spare power part from the orange box, drive our Mars rover up the hill, and fix the radio tower so Earth can help us find a new way home.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={onReplayCutscene}
              className="w-full sm:w-auto py-3 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-mono-hud text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-sky-400" />
              <span>Replay Scene</span>
            </button>

            <button
              onClick={onStartMission}
              className="w-full sm:flex-1 py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono-hud text-xs font-bold uppercase tracking-wider transition-colors shadow-lg flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Mission 1</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
