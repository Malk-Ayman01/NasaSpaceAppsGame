import React from 'react';
import { RotateCcw, Home, AlertTriangle } from 'lucide-react';

interface GameOverModalProps {
  onRestart: () => void;
  onReturnToMenu?: () => void;
  reason?: string;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  onRestart,
  onReturnToMenu,
  reason = 'Your suit air ran out before getting back to the safe base.',
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-red-950/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-950 border-2 border-red-600/80 p-6 sm:p-8 text-white shadow-2xl text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-red-600/20 text-red-500 border border-red-500/50 mb-4 animate-pulse">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <div className="font-mono-hud text-xs tracking-widest text-red-400 font-bold uppercase mb-1">
          OOPS! TRY AGAIN
        </div>
        <h1 className="font-title text-3xl sm:text-4xl font-black tracking-wider uppercase text-white drop-shadow-md">
          MISSION STOPPED
        </h1>

        <div className="my-5 p-4 rounded-xl bg-red-900/30 border border-red-500/40 text-left">
          <div className="flex items-center gap-2 text-xs font-mono-hud font-bold text-red-400 mb-1">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>WHAT HAPPENED:</span>
          </div>
          <p className="font-mono-hud text-xs text-red-200 leading-relaxed">
            {reason}
          </p>
        </div>

        <p className="font-mono-hud text-xs text-slate-300 mb-6">
          Tip: Stand inside the green circle at your base to fill your air back to 100%!
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          {onReturnToMenu && (
            <button
              onClick={onReturnToMenu}
              className="flex-1 py-3.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono-hud text-xs font-bold uppercase transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
            >
              <Home className="w-4 h-4" />
              <span>Main Menu</span>
            </button>
          )}
          <button
            onClick={onRestart}
            className="flex-1 py-3.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono-hud text-sm font-bold tracking-wider uppercase transition-all shadow-xl flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Try Again</span>
          </button>
        </div>
      </div>
    </div>
  );
};
