import type { CrewMember } from '../data/CrewData';

interface CrewDetailsPageProps {
  crew: CrewMember;
  onBack: () => void;
  onContinue: () => void;
}

const crewStories: Record<string, string> = {
  '01-BIO': `Hedeya is the team's Fix-It and Life Support Engineer! She knows how every spacesuit, air filter, and power wire works on Mars.

When the ship had an emergency during the mission, Hedeya stayed calm and checked the air tanks and rover batteries right away so the whole team could stay safe.

She loves solving tricky engineering puzzles and helping Hazaloom and Samantha fix broken tools fast!`,

  '02-ENG': `Samantha is the Space Scientist and Power Lead on the Ares Mars mission! She studies ancient Mars rivers, underground lava caves, and rover power systems.

During the ship landing and power emergencies, Samantha watched every warning gauge closely so the crew never ran out of energy.

Smart, brave, and curious, Samantha guides the team toward safe spots on Mars—and helps find a new way home!`,

  '03-CMD': `Hazaloom is the Mission Commander and Rover Driver! With years of flight and driving training, Hazaloom leads the team across rocky Jezero Crater.

Whether grabbing spare parts outside base, steering the rover past giant Mars rocks, or piloting the Mars Rocket back into space, Hazaloom never gives up on the crew.

Steady, caring, and always ready for adventure, Hazaloom makes sure everyone makes it home safely!`,
};

const stats = [
  { label: 'HEART RATE', value: '084', unit: 'BPM', color: '#dc6547', percent: 70 },
  { label: 'FOCUS LEVEL', value: '95', unit: '%', color: '#dc8067', percent: 95 },
  { label: 'SUIT AIR', value: '100', unit: '%', color: '#b8a49e', percent: 100 },
  { label: 'SHIELDING', value: '96', unit: '%', color: '#e5a18b', percent: 96 },
];

export default function CrewDetailsPage({ crew, onBack, onContinue }: CrewDetailsPageProps) {
  const story = crewStories[crew.id] || 'CREW FILE READY FOR LAUNCH.';

  return (
    <section className="crew-details-page w-full h-full min-h-0 overflow-y-auto overflow-x-hidden">
      <div className="dossier-page-label">MISSION CONTROL // ASTRONAUT FILE</div>

      <div className="dossier-grid">
        {/* LEFT: CREW PROFILE */}
        <div className="dossier-card dossier-profile">
          <div className="dossier-id">&gt; CREW_ID: {crew.id}</div>

          <div className="dossier-image">
            {crew.image ? (
              <img
                src={crew.image}
                alt={crew.name}
                draggable={false}
                onError={(event) => {
                  event.currentTarget.style.display = 'none';
                }}
              />
            ) : (
              <span>CHARACTER IMAGE NOT AVAILABLE</span>
            )}
            <div className="dossier-image-strip" />
          </div>

          <h2 className="dossier-name">{crew.name}</h2>
          <p className="dossier-role">{crew.role}</p>

          <div className="dossier-divider" />

          <div className="dossier-section-label">&gt; SUIT &amp; HEALTH CHECK</div>

          <div className="dossier-stats">
            {stats.map((stat) => (
              <div className="dossier-stat" key={stat.label}>
                <div className="dossier-stat-heading">
                  <span>{stat.label}</span>
                  <strong style={{ color: stat.color }}>
                    {stat.value} {stat.unit}
                  </strong>
                </div>

                <div className="dossier-progress">
                  {Array.from({ length: 20 }, (_, index) => (
                    <span
                      key={index}
                      style={{
                        background: index < Math.ceil(stat.percent / 5) ? stat.color : '#241512',
                      }}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="dossier-monitoring">
            SYSTEM STATUS: <span>● READY FOR MARS</span>
          </div>
        </div>

        {/* RIGHT: PERSONNEL STORY */}
        <div className="dossier-card dossier-story-card">
          <div className="dossier-archive-label">CREW STORY // {crew.id}</div>

          <h2 className="dossier-story-title">MEET YOUR ASTRONAUT</h2>

          <div className="dossier-divider" />

          <div className="dossier-story">{story}</div>

          <div className="dossier-file-footer">
            <span>FILE: CREW_PROFILE.DAT</span>
            <span>STATUS: CLEARED TO PLAY</span>
          </div>

          <div className="dossier-divider dossier-actions-divider" />

          <div className="dossier-actions">
            <button type="button" onClick={onBack} className="dossier-back-button">
              &lt; BACK TO CREW
            </button>

            <button type="button" onClick={onContinue} className="dossier-continue-button">
              GO TO MISSIONS &gt;
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
