import React from 'react';
import {
  ArrowLeft,
  Lock,
  Radio,
  Satellite,
  Target,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';
import { MissionId } from '../types/game';

interface MissionsPageProps {
  completedMissions?: MissionId[];
  onSelectMission: (mission: MissionId) => void;
  onBack: () => void;
}

export default function MissionsPage({
  completedMissions = [],
  onSelectMission,
  onBack,
}: MissionsPageProps) {
  const m1Done = completedMissions.includes('mission_1');
  const m2Done = completedMissions.includes('mission_2');
  const m3Done = completedMissions.includes('mission_3');

  const m2Unlocked = m1Done;
  const m3Unlocked = m2Done;

  return (
    <main className="relative w-full h-full min-h-screen overflow-y-auto bg-[#0c0706] text-[#e5e7eb]">
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none">
        <img
          src="/assets/nasa/jezero_crater.jpg"
          alt="Mars surface"
          className="w-full h-full object-cover brightness-[0.2]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0c0706]/80 via-[#0c0706]/80 to-[#0c0706]" />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col px-6 sm:px-12 py-8">
        {/* Header */}
        <header className="flex items-center justify-between border-b border-[#49302b] pb-5">
          <div>
            <div className="flex items-center gap-2 text-red-400 font-mono-hud text-xs tracking-widest">
              <Radio className="w-4 h-4 animate-pulse" />
              ARES-1 // MISSION CONTROL
            </div>
            <h1 className="font-title text-3xl sm:text-5xl font-black mt-3 tracking-wider">
              MISSION SELECT
            </h1>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs font-mono-hud text-[#b8a49e]">
            <Satellite className="w-4 h-4 text-[#dc6547]" />
            MARS OPERATIONS
          </div>
        </header>

        {/* Intro */}
        <section className="mt-8 mb-6">
          <p className="font-mono-hud text-xs tracking-widest text-[#dc6547]">
            PERSONNEL CLEARED // MISSION DATABASE
          </p>
          <p className="text-sm text-[#b8a49e] mt-2 max-w-2xl leading-7">
            Finish Mission 1 to unlock Mission 2, and finish Mission 2 to unlock Mission 3!
          </p>
        </section>

        {/* Mission 1 */}
        <section className="max-w-5xl w-full mx-auto space-y-5">
          <div className="relative overflow-hidden border border-[#a34e38]/70 bg-[#160c09]/90">
            <div className="absolute inset-0">
              <img
                src="/assets/nasa/jezero_crater.jpg"
                alt="Jezero Crater"
                className="w-full h-full object-cover opacity-20"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#0c0706] via-[#0c0706]/90 to-transparent" />
            </div>

            <div className="relative z-10 p-6 sm:p-8">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="px-3 py-1 border border-red-500/40 bg-red-950/50 text-red-300 text-[10px] font-mono-hud tracking-widest">
                  MISSION 01
                </span>

                <span className="flex items-center gap-2 text-[10px] font-mono-hud text-emerald-400">
                  {m1Done ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      COMPLETED
                    </>
                  ) : (
                    <>
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      AVAILABLE
                    </>
                  )}
                </span>
              </div>

              <div className="max-w-xl mt-6">
                <div className="font-mono-hud text-xs tracking-[0.25em] text-[#dc8067]">
                  JEZERO CRATER
                </div>

                <h2 className="font-title text-2xl sm:text-4xl font-black text-white mt-2">
                  MISSION HOME BEGINS
                </h2>

                <p className="text-sm leading-7 text-[#c5b4ae] mt-3">
                  Check your Mars ship after landing, survive the sudden emergency, grab a spare part, drive the rover, fix the radio tower, and race back before the dust storm hits!
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-5">
                  <div className="border border-[#49302b] bg-[#0c0706]/80 p-3">
                    <Target className="w-4 h-4 text-[#dc6547] mb-1.5" />
                    <p className="text-[9px] font-mono-hud text-[#9b8580]">OBJECTIVE</p>
                    <p className="text-xs font-mono-hud text-[#e5a18b] mt-1">FIX THE RADIO</p>
                  </div>

                  <div className="border border-[#49302b] bg-[#0c0706]/80 p-3">
                    <Satellite className="w-4 h-4 text-[#dc6547] mb-1.5" />
                    <p className="text-[9px] font-mono-hud text-[#9b8580]">LOCATION</p>
                    <p className="text-xs font-mono-hud text-[#e5a18b] mt-1">MARS</p>
                  </div>

                  <div className="border border-[#49302b] bg-[#0c0706]/80 p-3 col-span-2 sm:col-span-1">
                    <Radio className="w-4 h-4 text-[#dc6547] mb-1.5" />
                    <p className="text-[9px] font-mono-hud text-[#9b8580]">STATUS</p>
                    <p className="text-xs font-mono-hud text-emerald-400 mt-1">READY</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectMission('mission_1')}
                  className="mt-6 flex items-center gap-3 px-7 py-3.5 bg-[#dc6547] hover:bg-[#ef795b] text-[#0c0706] font-mono-hud text-xs font-bold tracking-widest transition-all hover:scale-[1.02] cursor-pointer"
                >
                  SELECT MISSION 1
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Missions 2 & 3 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Mission 2 */}
            <div
              className={`border p-5 transition-all ${
                m2Unlocked
                  ? 'border-cyan-500/60 bg-[#12161c]/90'
                  : 'border-[#38241f] bg-[#120b09]/90 opacity-65'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="font-mono-hud text-xs text-[#9b8580]">MISSION 02</span>
                {m2Unlocked ? (
                  <span className="font-mono-hud text-[10px] text-cyan-400">
                    {m2Done ? 'COMPLETED' : 'UNLOCKED'}
                  </span>
                ) : (
                  <Lock className="w-4 h-4 text-[#806b65]" />
                )}
              </div>
              <h3 className="font-title text-xl text-white mt-3">UNDERGROUND CAVE</h3>
              <p className="font-mono-hud text-xs text-[#b8a49e] mt-2 leading-relaxed">
                {m2Unlocked
                  ? 'Place 2 ground sensors, drive into the dark lava cave, and drill a Mars rock!'
                  : 'Finish Mission 1 first to unlock this mission!'}
              </p>
              {m2Unlocked && (
                <button
                  type="button"
                  onClick={() => onSelectMission('mission_2')}
                  className="mt-4 flex items-center gap-2 px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-mono-hud text-xs font-bold tracking-wider cursor-pointer"
                >
                  SELECT MISSION 2 <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Mission 3 */}
            <div
              className={`border p-5 transition-all ${
                m3Unlocked
                  ? 'border-red-500/60 bg-[#181012]/90'
                  : 'border-[#38241f] bg-[#120b09]/90 opacity-65'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="font-mono-hud text-xs text-[#9b8580]">MISSION 03</span>
                {m3Unlocked ? (
                  <span className="font-mono-hud text-[10px] text-red-400">
                    {m3Done ? 'COMPLETED' : 'UNLOCKED'}
                  </span>
                ) : (
                  <Lock className="w-4 h-4 text-[#806b65]" />
                )}
              </div>
              <h3 className="font-title text-xl text-white mt-3">ROCKET HOME</h3>
              <p className="font-mono-hud text-xs text-[#b8a49e] mt-2 leading-relaxed">
                {m3Unlocked
                  ? 'Fix rover switches, dodge dust tornadoes, fly the Mars Rocket, and dock in space!'
                  : 'Finish Mission 2 first to unlock the rocket launch!'}
              </p>
              {m3Unlocked && (
                <button
                  type="button"
                  onClick={() => onSelectMission('mission_3')}
                  className="mt-4 flex items-center gap-2 px-5 py-2.5 bg-red-500 hover:bg-red-400 text-white font-mono-hud text-xs font-bold tracking-wider cursor-pointer"
                >
                  SELECT MISSION 3 <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-auto pt-10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-2 text-xs font-mono-hud text-[#b8a49e] hover:text-[#e5a18b] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            BACK TO CREW SELECTION
          </button>

          <span className="text-[10px] font-mono-hud text-[#806b65]">
            ARES-1 // MISSION DATABASE
          </span>
        </footer>
      </div>
    </main>
  );
}
