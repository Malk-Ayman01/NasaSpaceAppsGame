import React, { useState } from 'react';
import { Zap, ShieldAlert, Flame, Wind, Compass, Radio, CheckCircle, X } from 'lucide-react';
import { sounds } from '../audio/SoundManager';

interface PowerBusConsoleModalProps {
  onSolved: () => void;
  onClose: () => void;
}

export const PowerBusConsoleModal: React.FC<PowerBusConsoleModalProps> = ({
  onSolved,
  onClose,
}) => {
  const [busStates, setBusStates] = useState({
    auxBus2: true, // Broken Heater #2: 380W -> turn OFF
    spectrometer: true, // Rock Scanner: 180W -> turn OFF
    lifeSupport: true, // Suit Air: 140W -> keep ON
    driveMotors: true, // Rover Wheels: 210W -> keep ON
  });

  const totalWatts =
    (busStates.auxBus2 ? 380 : 0) +
    (busStates.spectrometer ? 180 : 0) +
    (busStates.lifeSupport ? 140 : 0) +
    (busStates.driveMotors ? 210 : 0);

  const isFaultIsolated = !busStates.auxBus2;
  const isLoadNominal = totalWatts <= 400;
  const areEssentialsOnline = busStates.lifeSupport && busStates.driveMotors;
  const isReadyToDrive = isFaultIsolated && isLoadNominal && areEssentialsOnline;

  const toggleBus = (key: keyof typeof busStates) => {
    sounds.playSwitchClick();
    setBusStates((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleLockAndDrive = () => {
    if (!isReadyToDrive) return;
    sounds.playObjectiveStinger();
    onSolved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-3xl bg-slate-950 border-2 border-amber-500/60 shadow-2xl p-5 sm:p-7 text-slate-100">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-hud font-bold text-red-400 uppercase tracking-wider mb-1">
              <Zap className="w-4 h-4 animate-pulse" />
              <span>ROVER POWER SWITCHES</span>
            </div>
            <h2 className="font-title text-xl sm:text-2xl font-bold text-white uppercase">
              Fix the Rover Power!
            </h2>
            <p className="font-mono-hud text-xs text-slate-300 mt-1">
              Turn <b className="text-red-400">OFF</b> the Broken Heater and Rock Scanner so total power drops to <b className="text-emerald-400">400W or less</b>. Keep Suit Air and Rover Wheels <b className="text-sky-400">ON</b>!
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Total Load Meter */}
        <div className="my-4 p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between mb-2 font-mono-hud text-xs">
            <span className="text-slate-300 font-bold uppercase">POWER USED (MUST BE 400W OR LESS)</span>
            <span
              className={`font-bold text-base ${
                isLoadNominal ? 'text-emerald-400' : 'text-red-400 animate-pulse'
              }`}
            >
              {totalWatts} W {isLoadNominal ? '// SAFE!' : '// TOO HIGH!'}
            </span>
          </div>
          <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 rounded-full ${
                isLoadNominal ? 'bg-emerald-400' : totalWatts > 600 ? 'bg-red-500' : 'bg-amber-400'
              }`}
              style={{ width: `${Math.min(100, (totalWatts / 910) * 100)}%` }}
            />
          </div>
        </div>

        {/* Interactive Breaker Switches */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Broken Heater #2 */}
          <button
            onClick={() => toggleBus('auxBus2')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              busStates.auxBus2
                ? 'bg-red-950/50 border-red-500/80 shadow-lg shadow-red-500/10'
                : 'bg-slate-900/70 border-emerald-500/50'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2 text-xs font-mono-hud font-bold">
                <Flame className={`w-4 h-4 ${busStates.auxBus2 ? 'text-red-400 animate-pulse' : 'text-slate-500'}`} />
                <span className="text-white">BROKEN HEATER (#2)</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded font-mono-hud text-[10px] font-bold ${
                  busStates.auxBus2 ? 'bg-red-500 text-white' : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {busStates.auxBus2 ? 'ON (BROKEN!)' : 'OFF (SAFE)'}
              </span>
            </div>
            <div className="font-mono-hud text-[11px] text-slate-300">
              Uses: <b className={busStates.auxBus2 ? 'text-red-300' : 'text-slate-500'}>{busStates.auxBus2 ? '380W' : '0W'}</b> — Broken by Mars dust. Click to turn OFF!
            </div>
          </button>

          {/* Rock Scanner */}
          <button
            onClick={() => toggleBus('spectrometer')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              busStates.spectrometer
                ? 'bg-amber-950/40 border-amber-500/60'
                : 'bg-slate-900/70 border-emerald-500/50'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2 text-xs font-mono-hud font-bold">
                <Radio className={`w-4 h-4 ${busStates.spectrometer ? 'text-amber-400' : 'text-slate-500'}`} />
                <span className="text-white">ROCK SCANNER</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded font-mono-hud text-[10px] font-bold ${
                  busStates.spectrometer ? 'bg-amber-500 text-black' : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {busStates.spectrometer ? 'ON' : 'SLEEPING'}
              </span>
            </div>
            <div className="font-mono-hud text-[11px] text-slate-300">
              Uses: <b className={busStates.spectrometer ? 'text-amber-300' : 'text-slate-500'}>{busStates.spectrometer ? '180W' : '0W'}</b> — Not needed right now. Click to rest!
            </div>
          </button>

          {/* Suit Air */}
          <button
            onClick={() => toggleBus('lifeSupport')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              busStates.lifeSupport
                ? 'bg-sky-950/40 border-sky-500/60'
                : 'bg-red-950/60 border-red-500 animate-pulse'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2 text-xs font-mono-hud font-bold">
                <Wind className={`w-4 h-4 ${busStates.lifeSupport ? 'text-sky-400' : 'text-red-400'}`} />
                <span className="text-white">SUIT AIR</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded font-mono-hud text-[10px] font-bold ${
                  busStates.lifeSupport ? 'bg-sky-500 text-black' : 'bg-red-500 text-white'
                }`}
              >
                {busStates.lifeSupport ? 'ON' : 'OFF (NEEDED!)'}
              </span>
            </div>
            <div className="font-mono-hud text-[11px] text-slate-300">
              Uses: <b>{busStates.lifeSupport ? '140W' : '0W'}</b> — Keeps air clean to breathe!
            </div>
          </button>

          {/* Rover Wheels */}
          <button
            onClick={() => toggleBus('driveMotors')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              busStates.driveMotors
                ? 'bg-sky-950/40 border-sky-500/60'
                : 'bg-red-950/60 border-red-500 animate-pulse'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2 text-xs font-mono-hud font-bold">
                <Compass className={`w-4 h-4 ${busStates.driveMotors ? 'text-sky-400' : 'text-red-400'}`} />
                <span className="text-white">ROVER WHEELS</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded font-mono-hud text-[10px] font-bold ${
                  busStates.driveMotors ? 'bg-sky-500 text-black' : 'bg-red-500 text-white'
                }`}
              >
                {busStates.driveMotors ? 'ON' : 'OFF (NEEDED!)'}
              </span>
            </div>
            <div className="font-mono-hud text-[11px] text-slate-300">
              Uses: <b>{busStates.driveMotors ? '210W' : '0W'}</b> — Needed to drive to the rocket!
            </div>
          </button>
        </div>

        {/* Footer Guidance & Action */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-mono-hud">
            {isReadyToDrive ? (
              <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle className="w-4 h-4" />
                HEDEYA: “Great job! Power is 350W! Let us drive!”
              </span>
            ) : !areEssentialsOnline ? (
              <span className="flex items-center gap-1.5 text-red-400 font-bold">
                <ShieldAlert className="w-4 h-4" />
                Keep Suit Air and Rover Wheels ON!
              </span>
            ) : (
              <span className="text-amber-300">
                HEDEYA: “Click Broken Heater (#2) and Rock Scanner to turn them OFF.”
              </span>
            )}
          </div>

          <button
            onClick={handleLockAndDrive}
            disabled={!isReadyToDrive}
            className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-mono-hud text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              isReadyToDrive
                ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg cursor-pointer hover:scale-[1.02]'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Save &amp; Drive Rover!</span>
          </button>
        </div>
      </div>
    </div>
  );
};
