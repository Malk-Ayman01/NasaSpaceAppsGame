import React, { useEffect, useState } from 'react';
import { GameResources, MissionStage, Waypoint, MissionId } from '../types/game';
import {
  Wind,
  Battery,
  ShieldAlert,
  Zap,
  BookOpen,
  Volume2,
  VolumeX,
  AlertTriangle,
  Menu,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { sounds } from '../audio/SoundManager';

interface HUDProps {
  resources: GameResources;
  stage: MissionStage;
  activeMission: MissionId;
  waypoint: Waypoint | null;
  interactionPrompt: string | null;
  warningMessage: string | null;
  discoveredFactsCount: number;
  totalFactsCount: number;
  onOpenFieldGuide: () => void;
  onOpenPauseMenu: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  resources,
  stage,
  activeMission,
  waypoint,
  interactionPrompt,
  warningMessage,
  discoveredFactsCount,
  totalFactsCount,
  onOpenFieldGuide,
  onOpenPauseMenu,
}) => {
  const [isMuted, setIsMuted] = useState(sounds.getMuted());
  const [lastObjective, setLastObjective] = useState<string>('');
  const [showObjectiveBanner, setShowObjectiveBanner] = useState(false);

  const getObjectiveText = (): string => {
    switch (stage) {
      // Mission 1
      case 'stage_0_opening_explore':
        return 'Walk to the blue circle next to the ship and press [E] to check it!';
      case 'stage_1_leave_habitat':
        return 'Walk out of base to grab the power part!';
      case 'stage_2_collect_coupler':
        return 'Go to the orange box and press [E] to get the power part!';
      case 'stage_3_drive_rover':
        return 'Walk to the rover and press [E] to get in!';
      case 'stage_4_repair_relay':
        return resources.hasCoupler
          ? 'Drive past the rocks to the radio tower and press [E] to fix it!'
          : 'Get the power part from the orange box first!';
      case 'stage_5_escape_storm':
        return 'DUST STORM! Hurry back to the safe base!';
      case 'cinematic_ending':
        return 'Mission 1 Done! You are safe at base!';

      // Mission 2
      case 'm2_stage_1_canyon_transit':
        return 'Drive to the first yellow circle and press [E] to drop Sensor 1!';
      case 'm2_stage_2_deploy_beacons':
        return 'Drive north to drop Sensor 2!';
      case 'm2_stage_3_lava_tube_entry':
        return 'Drive to the cave hole and press [E] to go underground!';
      case 'm2_stage_4_sample_extraction':
        return 'Go to the glowing blue rock and press [E] to drill!';
      case 'm2_stage_5_seismic_evacuation':
        return 'GROUND SHAKE! Drive fast back to the blue cave exit!';
      case 'm2_cinematic_ending':
        return 'Mission 2 Done! You saved the Mars rock!';

      // Mission 3
      case 'm3_stage_1_grid_triage':
        return 'Walk to the rover and press [E] to fix the power switches!';
      case 'm3_stage_2_scarp_traverse':
        return 'Drive east to the Mars Rocket! Watch out for dust tornadoes!';
      case 'm3_stage_3_mav_transfer':
        return 'Go to the yellow circle by the rocket and press [E] to get in!';
      case 'm3_stage_4_mav_ascent':
        return 'FLY THE ROCKET! Press [A] or [D] to stay in the green box!';
      case 'm3_stage_5_orbital_dock':
        return 'DOCK IN SPACE! Use [WASD] or Arrows to steer into the spaceship ring!';
      case 'm3_cinematic_ending':
        return 'You did it! Heading back home to Earth!';

      default:
        return 'Explore Mars!';
    }
  };

  const currentObjective = getObjectiveText();

  useEffect(() => {
    if (currentObjective !== lastObjective && currentObjective !== '') {
      setLastObjective(currentObjective);
      setShowObjectiveBanner(true);
      const timer = setTimeout(() => setShowObjectiveBanner(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [currentObjective, lastObjective]);

  const handleToggleSound = () => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  const isLowOxygen = resources.oxygen < 25 && !resources.isInsideHabitat;
  const isLowBattery = resources.battery < 20 && resources.isInRover;
  const isDamagedRover = resources.condition < 30;

  const missionTitle =
    activeMission === 'mission_3'
      ? 'Mission 3: Rocket Home'
      : activeMission === 'mission_2'
      ? 'Mission 2: Underground Cave'
      : 'Mission 1: Fix the Radio';

  const sectorBadge =
    activeMission === 'mission_3'
      ? stage === 'm3_stage_4_mav_ascent'
        ? `ROCKET UP // HEIGHT: ${resources.mavAltitudeKm ?? 0} KM // SPEED: ${resources.mavVelocityMs ?? 0}`
        : stage === 'm3_stage_5_orbital_dock'
        ? 'IN SPACE // MEET THE HOME SPACESHIP'
        : 'ROCKY ROAD TO ROCKET PAD'
      : activeMission === 'mission_2'
      ? resources.isInLavaTube
        ? 'UNDERGROUND LAVA CAVE'
        : 'OLD RIVER VALLEY'
      : stage === 'stage_0_opening_explore'
      ? 'LANDING SITE — ALL SYSTEMS CALM'
      : resources.isInsideHabitat
      ? 'SAFE AT DAMAGED SHIP (AIR FILLING)'
      : resources.isDustStormActive
      ? 'DUST STORM OUTSIDE!'
      : 'OUTSIDE ON MARS';

  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex flex-col justify-between p-4 sm:p-6 overflow-hidden">
      {/* 1. TOP HEADER */}
      <div className="flex items-start justify-between w-full gap-2">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span
              className={`inline-block w-2.5 h-2.5 rounded-full ${
                resources.seismicTremor ? 'bg-amber-400 animate-ping' : 'bg-red-500 animate-pulse'
              }`}
            />
            <span className="font-mono-hud text-xs tracking-wider text-red-400 font-bold uppercase">
              MARS ADVENTURE //{' '}
              {activeMission === 'mission_3'
                ? 'ROCKET LAUNCH'
                : activeMission === 'mission_2'
                ? 'CAVE EXPLORER'
                : 'RADIO RESCUE'}
            </span>
          </div>
          <h1 className="font-title text-xl sm:text-2xl font-bold tracking-wider text-slate-100 uppercase drop-shadow-md">
            {missionTitle}
          </h1>
          <div className="flex items-center gap-2 text-xs font-mono-hud text-slate-300">
            <span className={resources.seismicTremor ? 'text-amber-400 font-bold animate-pulse' : 'text-amber-300'}>
              {resources.seismicTremor ? 'CAVE IS SHAKING! HURRY OUT!' : sectorBadge}
            </span>
          </div>
          {/* Always-visible mini goal line so young players never forget what to do */}
          <div className="mt-1 inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-black/75 border border-amber-500/40 text-xs font-mono-hud text-amber-200 max-w-md">
            <span className="font-bold text-amber-400 shrink-0">GOAL:</span>
            <span className="truncate">{currentObjective}</span>
          </div>
        </div>

        {/* Right: Quick Buttons */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={onOpenFieldGuide}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-700/80 hover:border-amber-500/80 hover:bg-slate-800 text-xs font-mono-hud text-slate-200 transition-all shadow-lg backdrop-blur cursor-pointer"
            title="Open NASA Space Facts Book"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span className="hidden md:inline">Space Facts</span>
            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
              {discoveredFactsCount}/{totalFactsCount}
            </span>
          </button>

          <button
            onClick={handleToggleSound}
            className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 hover:border-slate-500 hover:bg-slate-800 text-slate-300 transition-all shadow-lg backdrop-blur cursor-pointer"
            title={isMuted ? 'Turn Sound On' : 'Turn Sound Off'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={onOpenPauseMenu}
            className="p-2 rounded-lg bg-slate-900/80 border border-slate-700/80 hover:border-slate-500 hover:bg-slate-800 text-slate-300 transition-all shadow-lg backdrop-blur cursor-pointer"
            title="Pause Game"
          >
            <Menu className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </div>

      {/* 2. OBJECTIVE BANNER */}
      <div className="w-full flex flex-col items-center justify-center my-auto">
        {showObjectiveBanner && (
          <div className="animate-in fade-in zoom-in-95 duration-300 flex flex-col items-center bg-black/85 border-y-2 border-amber-500 px-6 sm:px-12 py-3 shadow-2xl backdrop-blur-md max-w-2xl text-center">
            <span className="font-mono-hud text-xs tracking-widest text-amber-400 font-bold uppercase mb-1">
              NEW GOAL!
            </span>
            <span className="font-title text-base sm:text-xl font-bold tracking-wide text-white uppercase">
              {currentObjective}
            </span>
          </div>
        )}

        {warningMessage && (
          <div className="mt-3 flex items-center gap-2 px-4 py-2 rounded-lg bg-red-950/90 border border-red-500/80 text-red-200 font-mono-hud text-xs shadow-xl animate-bounce backdrop-blur">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{warningMessage}</span>
          </div>
        )}
      </div>

      {/* 3. INTERACTION PROMPT */}
      <div className="w-full flex justify-center mb-2">
        {interactionPrompt && (
          <div className="pointer-events-auto px-5 py-2.5 rounded-full bg-slate-900/95 border-2 border-amber-400 text-white font-mono-hud text-sm font-bold tracking-wider shadow-2xl flex items-center gap-2.5 animate-pulse backdrop-blur">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
            <span>{interactionPrompt}</span>
          </div>
        )}
      </div>

      {/* 4. BOTTOM BAR: RADAR (LEFT) & STATUS BARS (RIGHT) */}
      <div className="flex items-end justify-between w-full">
        {/* LEFT: SIMPLE MAP RADAR */}
        <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-slate-950/90 border-2 border-slate-700/90 shadow-2xl overflow-hidden backdrop-blur-md flex items-center justify-center">
          <div className="absolute inset-2 rounded-full border border-slate-800/80 pointer-events-none" />
          <div className="absolute inset-6 rounded-full border border-slate-800/60 pointer-events-none" />
          <div className="absolute inset-10 rounded-full border border-slate-800/40 pointer-events-none" />
          <div className="absolute w-full h-[1px] bg-slate-800/60" />
          <div className="absolute h-full w-[1px] bg-slate-800/60" />

          <span className="absolute top-1 text-[9px] font-mono-hud font-bold text-slate-400">N</span>
          <span className="absolute bottom-1 text-[9px] font-mono-hud font-bold text-slate-500">S</span>
          <span className="absolute left-1.5 text-[9px] font-mono-hud font-bold text-slate-500">W</span>
          <span className="absolute right-1.5 text-[9px] font-mono-hud font-bold text-slate-500">E</span>

          <div className="w-3 h-3 rounded-full bg-white shadow-lg shadow-white/80 border border-slate-900 z-10 flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-sky-400" />
          </div>

          {waypoint && (
            <div
              className="absolute z-20 flex flex-col items-center justify-center animate-pulse"
              style={{
                transform: `translate(${Math.min(55, Math.max(-55, (waypoint.x - 1000) / 30))}px, ${Math.min(
                  55,
                  Math.max(-55, (waypoint.y - 1000) / 30)
                )}px)`,
              }}
            >
              <div className="w-2.5 h-2.5 rotate-45 bg-amber-400 border border-amber-200 shadow-md shadow-amber-400/80" />
            </div>
          )}

          {waypoint && (
            <div className="absolute bottom-2 px-2 py-0.5 rounded bg-black/80 border border-amber-500/50 text-[10px] font-mono-hud font-bold text-amber-300">
              {waypoint.distanceMeters}m
            </div>
          )}
        </div>

        {/* RIGHT: STATUS METERS */}
        <div className="flex flex-col gap-2 items-end">
          {/* MISSION 2: RADAR SIGNAL */}
          {activeMission === 'mission_2' && (
            <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-950/85 border border-cyan-500/40 backdrop-blur-md shadow-xl">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-400">
                <Activity className="w-4 h-4 animate-pulse" />
              </div>
              <div className="flex flex-col w-28 sm:w-36">
                <div className="flex justify-between items-center text-[10px] font-mono-hud mb-1">
                  <span className="text-cyan-300 font-bold uppercase">Cave Signal</span>
                  <span className="text-cyan-400 font-bold">{resources.signalStrength ?? 20}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-all duration-300 rounded-full"
                    style={{ width: `${resources.signalStrength ?? 20}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* SUIT AIR METER */}
          <div
            className={`flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-950/85 border backdrop-blur-md shadow-xl transition-all ${
              isLowOxygen ? 'border-red-500/90 shadow-red-500/20 animate-pulse' : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-sky-950/60 border border-sky-500/40 text-sky-400">
              <Wind className="w-4 h-4" />
            </div>
            <div className="flex flex-col w-28 sm:w-36">
              <div className="flex justify-between items-center text-[11px] font-mono-hud mb-1">
                <span className="text-slate-300 font-bold uppercase">Suit Air</span>
                <span className={isLowOxygen ? 'text-red-400 font-bold' : 'text-sky-300 font-bold'}>
                  {Math.round(resources.oxygen)}%
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className={`h-full transition-all duration-200 rounded-full ${
                    resources.oxygen > 50
                      ? 'bg-sky-400'
                      : resources.oxygen > 25
                      ? 'bg-amber-400'
                      : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.max(0, Math.min(100, resources.oxygen))}%` }}
                />
              </div>
            </div>
          </div>

          {/* ROVER METERS */}
          {(resources.isInRover || resources.condition < 100) && (
            <div className="flex flex-col gap-2 p-2.5 rounded-xl bg-slate-950/85 border border-slate-800 backdrop-blur-md shadow-xl">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-amber-950/60 border border-amber-500/40 text-amber-400">
                  <Battery className="w-4 h-4" />
                </div>
                <div className="flex flex-col w-28 sm:w-36">
                  <div className="flex justify-between items-center text-[10px] font-mono-hud mb-0.5">
                    <span className="text-slate-300 font-bold uppercase">Rover Battery</span>
                    <span className={isLowBattery ? 'text-red-400 font-bold' : 'text-amber-300 font-bold'}>
                      {Math.round(resources.battery)}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-200 rounded-full ${
                        resources.battery > 40 ? 'bg-amber-400' : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.max(0, Math.min(100, resources.battery))}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-400">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div className="flex flex-col w-28 sm:w-36">
                  <div className="flex justify-between items-center text-[10px] font-mono-hud mb-0.5">
                    <span className="text-slate-300 font-bold uppercase">Rover Health</span>
                    <span className={isDamagedRover ? 'text-red-400 font-bold' : 'text-emerald-300 font-bold'}>
                      {Math.round(resources.condition)}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-200 rounded-full ${
                        resources.condition > 50
                          ? 'bg-emerald-400'
                          : resources.condition > 25
                          ? 'bg-amber-400'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.max(0, Math.min(100, resources.condition))}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* BAG / MISSION ITEMS */}
          <div className="flex flex-col gap-1 items-end">
            {activeMission === 'mission_1' ? (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                <Zap className={`w-3.5 h-3.5 ${resources.hasCoupler ? 'text-cyan-400' : 'text-slate-600'}`} />
                <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-300">
                  Power Part:
                </span>
                <span
                  className={`text-[10px] font-mono-hud font-bold px-1.5 py-0.5 rounded ${
                    resources.hasCoupler ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {resources.hasCoupler ? 'GOT IT!' : 'NOT YET'}
                </span>
              </div>
            ) : activeMission === 'mission_2' ? (
              <>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                  <Layers className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-300">
                    Sensors:
                  </span>
                  <span className="text-[10px] font-mono-hud font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    {resources.beaconsPlaced ?? 0}/{resources.totalBeacons ?? 2} Dropped
                  </span>
                </div>

                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                  <Sparkles className={`w-3.5 h-3.5 ${resources.hasCoreSample ? 'text-cyan-400' : 'text-slate-600'}`} />
                  <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-300">
                    Mars Rock:
                  </span>
                  <span
                    className={`text-[10px] font-mono-hud font-bold px-1.5 py-0.5 rounded ${
                      resources.hasCoreSample ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {resources.hasCoreSample ? 'TUBE #14 SAVED' : 'NOT YET'}
                  </span>
                </div>
              </>
            ) : (
              <>
                {stage === 'm3_stage_4_mav_ascent' ? (
                  <div className="flex flex-col gap-1 p-2.5 rounded-xl bg-slate-950/90 border border-amber-500/60 backdrop-blur-md shadow-2xl">
                    <div className="flex justify-between items-center text-[10px] font-mono-hud text-amber-400 font-bold">
                      <span>MARS ROCKET</span>
                      <span>PART {resources.mavStage ?? 1}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] font-mono-hud">
                      <span className="text-slate-300">HEIGHT: <b className="text-white">{resources.mavAltitudeKm ?? 0} km</b></span>
                      <span className="text-slate-300">SPEED: <b className="text-sky-400">{resources.mavVelocityMs ?? 0}</b></span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden mt-0.5">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-200"
                        style={{ width: `${Math.min(100, ((resources.mavAltitudeKm ?? 0) / 120) * 100)}%` }}
                      />
                    </div>
                  </div>
                ) : stage === 'm3_stage_5_orbital_dock' ? (
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-950/80 border border-cyan-500/60 backdrop-blur-md">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                    <span className="text-[10px] font-mono-hud uppercase tracking-wider text-cyan-300 font-bold">
                      {resources.mavDocked ? 'DOCKED SAFE!' : 'STEER TO SPACESHIP!'}
                    </span>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                      <Zap className={`w-3.5 h-3.5 ${resources.breakersConfigured ? 'text-emerald-400' : 'text-red-400 animate-pulse'}`} />
                      <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-300">
                        Heater #2:
                      </span>
                      <span
                        className={`text-[10px] font-mono-hud font-bold px-1.5 py-0.5 rounded ${
                          resources.breakersConfigured ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
                        }`}
                      >
                        {resources.breakersConfigured ? 'FIXED!' : 'BROKEN!'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 backdrop-blur-md">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-300">
                        Bag:
                      </span>
                      <span className="text-[10px] font-mono-hud font-bold px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                        MARS ROCK #14
                      </span>
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
