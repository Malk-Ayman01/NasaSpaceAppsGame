import React, { useState, useRef, useCallback } from 'react';
import { MarsGameCanvas } from './game/MarsGameCanvas';
import { SceneCallbacks } from './game/scenes/Mission1Scene';
import { HUD } from './components/HUD';
import { DialogueOverlay } from './components/DialogueOverlay';
import { EducationalModal } from './components/EducationalModal';
import { MissionCompleteModal } from './components/MissionCompleteModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseMenu } from './components/PauseMenu';
import { NasaFieldGuide } from './components/NasaFieldGuide';
import { MainMenu } from './components/MainMenu';
import { PowerBusConsoleModal } from './components/PowerBusConsoleModal';
import { DisasterCinematicModal } from './components/DisasterCinematicModal';
import { DamagedShipStatusModal } from './components/DamagedShipStatusModal';
import HomePage from './components/HomePage';
import LoadingScreen from './components/LoadingScreen';
import CrewSelectionPage from './components/CrewSelectionPage';
import MissionsPage from './components/MissionsPage';
import RotateDevice from './components/RotateDevice';
import { CrewMember } from './data/CrewData';
import { DIALOGUE_SCRIPTS, NASA_FACTS } from './data/nasaContent';
import {
  GameResources,
  MissionStage,
  Waypoint,
  DialogueLine,
  EducationalFact,
  MissionStats,
  MissionId,
} from './types/game';
import { sounds } from './audio/SoundManager';

type GameScreenState =
  | 'home'
  | 'loading'
  | 'crew_selection'
  | 'missions'
  | 'menu'
  | 'playing'
  | 'mission_complete'
  | 'mission_failed';

const COMPLETED_STORAGE_KEY = 'mars_mission_completed_v1';

function loadCompletedMissions(): MissionId[] {
  try {
    const raw = window.localStorage.getItem(COMPLETED_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (id): id is MissionId => id === 'mission_1' || id === 'mission_2' || id === 'mission_3'
    );
  } catch {
    return [];
  }
}

function isMissionUnlocked(missionId: MissionId, completed: MissionId[]): boolean {
  if (missionId === 'mission_1') return true;
  if (missionId === 'mission_2') return completed.includes('mission_1');
  if (missionId === 'mission_3') return completed.includes('mission_2');
  return false;
}

export default function App() {
  const [activeMission, setActiveMission] = useState<MissionId>('mission_1');
  const [completedMissions, setCompletedMissions] = useState<MissionId[]>(loadCompletedMissions);
  const [selectedCrew, setSelectedCrew] = useState<CrewMember | null>(null);
  const [screenState, setScreenState] = useState<GameScreenState>('home');
  const [stage, setStage] = useState<MissionStage>('stage_0_opening_explore');

  const [resources, setResources] = useState<GameResources>({
    oxygen: 100,
    battery: 100,
    condition: 100,
    hasCoupler: false,
    isInRover: false,
    isInsideHabitat: true,
    isDustStormActive: false,
    elapsedSeconds: 0,
    rockCollisions: 0,
    signalStrength: 20,
    beaconsPlaced: 0,
    totalBeacons: 2,
    hasCoreSample: false,
    isInLavaTube: false,
    seismicTremor: false,
  });

  const [activeDialogue, setActiveDialogue] = useState<DialogueLine[] | null>(null);
  const [activeEducationalFact, setActiveEducationalFact] = useState<EducationalFact | null>(null);
  const [unlockedFactIds, setUnlockedFactIds] = useState<string[]>([]);
  const [waypoint, setWaypoint] = useState<Waypoint | null>(null);
  const [interactionPrompt, setInteractionPrompt] = useState<string | null>(null);
  const [warningMessage, setWarningMessage] = useState<string | null>(null);

  const [isPaused, setIsPaused] = useState(false);
  const [isFieldGuideOpen, setIsFieldGuideOpen] = useState(false);
  const [isBreakerConsoleOpen, setIsBreakerConsoleOpen] = useState(false);
  const [isDisasterCutsceneOpen, setIsDisasterCutsceneOpen] = useState(false);
  const [isDamagedStatusOpen, setIsDamagedStatusOpen] = useState(false);

  const gameRef = useRef<{
    resetMission: () => void;
    solveBreakerTriage?: () => void;
    startPostDisasterMission?: () => void;
  } | null>(null);

  const warningTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const markMissionComplete = useCallback((missionId: MissionId) => {
    setCompletedMissions((prev) => {
      if (prev.includes(missionId)) return prev;
      const next = [...prev, missionId];
      try {
        window.localStorage.setItem(COMPLETED_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage write issues
      }
      return next;
    });
  }, []);

  const handleWarning = useCallback((msg: string) => {
    setWarningMessage(msg);
    if (warningTimeoutRef.current) clearTimeout(warningTimeoutRef.current);
    warningTimeoutRef.current = setTimeout(() => {
      setWarningMessage(null);
    }, 4000);
  }, []);

  const handleDialogueTrigger = useCallback((dialogueKey: string) => {
    const lines = DIALOGUE_SCRIPTS[dialogueKey];
    if (lines && lines.length > 0) {
      setActiveDialogue(lines);
    }
  }, []);

  const handleFactUnlock = useCallback((factId: string) => {
    setUnlockedFactIds((prev) => {
      if (!prev.includes(factId)) {
        const fact = NASA_FACTS.find((f) => f.id === factId);
        if (fact) {
          setTimeout(() => {
            setActiveEducationalFact(fact);
          }, 800);
        }
        return [...prev, factId];
      }
      return prev;
    });
  }, []);

  const handleStageChange = useCallback((newStage: MissionStage) => {
    setStage(newStage);
  }, []);

  const handleMissionEnd = useCallback(
    (success: boolean) => {
      if (success) {
        markMissionComplete(activeMission);
        setScreenState('mission_complete');
      } else {
        setScreenState('mission_failed');
      }
    },
    [activeMission, markMissionComplete]
  );

  const callbacks: SceneCallbacks = {
    onResourceUpdate: (res) => {
      setResources(res);
      if (res.oxygen <= 0 && screenState === 'playing') {
        setScreenState('mission_failed');
      }
    },
    onStageChange: handleStageChange,
    onPromptChange: (prompt) => setInteractionPrompt(prompt),
    onDialogueTrigger: handleDialogueTrigger,
    onFactUnlock: handleFactUnlock,
    onWarning: handleWarning,
    onWaypointUpdate: (wp) => setWaypoint(wp),
    onMissionEnd: handleMissionEnd,
    onOpenBreakerConsole: () => setIsBreakerConsoleOpen(true),
    onTriggerDisasterCinematic: () => {
      setActiveDialogue(null);
      setActiveEducationalFact(null);
      setIsPaused(false);
      setIsDamagedStatusOpen(false);
      setIsDisasterCutsceneOpen(true);
    },
  };

  const resetUiForMissionStart = (missionId: MissionId) => {
    setIsPaused(false);
    setIsBreakerConsoleOpen(false);
    setIsDisasterCutsceneOpen(false);
    setIsDamagedStatusOpen(false);
    setActiveDialogue(null);
    setActiveEducationalFact(null);
    setInteractionPrompt(null);
    setWarningMessage(null);
    setStage(
      missionId === 'mission_3'
        ? 'm3_stage_1_grid_triage'
        : missionId === 'mission_2'
        ? 'm2_stage_1_canyon_transit'
        : 'stage_0_opening_explore'
    );
    setResources({
      oxygen: 100,
      battery: 100,
      condition: 100,
      hasCoupler: false,
      isInRover: false,
      isInsideHabitat: true,
      isDustStormActive: false,
      elapsedSeconds: 0,
      rockCollisions: 0,
      signalStrength: 20,
      beaconsPlaced: 0,
      totalBeacons: 2,
      hasCoreSample: missionId === 'mission_3',
      isInLavaTube: false,
      seismicTremor: false,
      breakersConfigured: false,
    });
  };

  const handleSelectMission = (missionId: MissionId) => {
    if (!isMissionUnlocked(missionId, completedMissions)) return;
    setActiveMission(missionId);
    setStage(
      missionId === 'mission_3'
        ? 'm3_stage_1_grid_triage'
        : missionId === 'mission_2'
        ? 'm2_stage_1_canyon_transit'
        : 'stage_0_opening_explore'
    );
  };

  const handleStartGame = () => {
    if (!isMissionUnlocked(activeMission, completedMissions)) return;
    resetUiForMissionStart(activeMission);
    setScreenState('playing');
    sounds.playObjectiveStinger();
  };

  const handleRestartMission = () => {
    resetUiForMissionStart(activeMission);
    setScreenState('playing');
    gameRef.current?.resetMission();
  };

  const handleContinueToMission2 = () => {
    if (!completedMissions.includes('mission_1')) return;
    setActiveMission('mission_2');
    resetUiForMissionStart('mission_2');
    setScreenState('playing');
  };

  const handleContinueToMission3 = () => {
    if (!completedMissions.includes('mission_2')) return;
    setActiveMission('mission_3');
    resetUiForMissionStart('mission_3');
    setScreenState('playing');
  };

  const handleReturnToMenu = () => {
    sounds.stopCinematicAudio();
    setIsPaused(false);
    setIsBreakerConsoleOpen(false);
    setIsDisasterCutsceneOpen(false);
    setIsDamagedStatusOpen(false);
    setActiveDialogue(null);
    setActiveEducationalFact(null);
    setScreenState('menu');
  };

  // Keyboard shortcut for Esc (Pause) and M (Space Facts Book)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (screenState !== 'playing' || isDisasterCutsceneOpen || isDamagedStatusOpen) return;
      if (e.code === 'Escape') {
        if (isBreakerConsoleOpen) {
          setIsBreakerConsoleOpen(false);
        } else {
          setIsPaused((prev) => !prev);
        }
      } else if (e.code === 'KeyM') {
        setIsFieldGuideOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screenState, isBreakerConsoleOpen, isDisasterCutsceneOpen, isDamagedStatusOpen]);

  const missionStats: MissionStats = {
    missionId: activeMission,
    elapsedSeconds: resources.elapsedSeconds,
    finalOxygen: resources.oxygen,
    finalBattery: resources.battery,
    finalCondition: resources.condition,
    factsDiscovered: unlockedFactIds.length,
    totalFacts: NASA_FACTS.length,
    rockCollisions: resources.rockCollisions,
    beaconsPlaced: resources.beaconsPlaced,
    hasCoreSample: resources.hasCoreSample,
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0c0706] font-display crt-overlay">
      <RotateDevice />

      {/* 0a. HOME PAGE */}
      {screenState === 'home' && (
        <HomePage onStart={() => setScreenState('loading')} />
      )}

      {/* 0b. LOADING SCREEN */}
      {screenState === 'loading' && (
        <LoadingScreen onComplete={() => setScreenState('crew_selection')} />
      )}

      {/* 0c. CREW SELECTION + DOSSIER */}
      {screenState === 'crew_selection' && (
        <CrewSelectionPage
          onContinue={(crew) => {
            setSelectedCrew(crew);
            setScreenState('missions');
          }}
          onBack={() => setScreenState('home')}
        />
      )}

      {/* 0d. MISSIONS OVERVIEW PAGE */}
      {screenState === 'missions' && (
        <MissionsPage
          completedMissions={completedMissions}
          onSelectMission={(missionId) => {
            handleSelectMission(missionId);
            setScreenState('menu');
          }}
          onBack={() => setScreenState('crew_selection')}
        />
      )}

      {/* 1. MAIN MENU SCREEN */}
      {screenState === 'menu' && (
        <MainMenu
          selectedMission={activeMission}
          completedMissions={completedMissions}
          selectedCrew={selectedCrew}
          onSelectMission={handleSelectMission}
          onStartGame={handleStartGame}
          onOpenFieldGuide={() => setIsFieldGuideOpen(true)}
          onChangeCrew={() => setScreenState('crew_selection')}
          onBackToHome={() => setScreenState('home')}
        />
      )}

      {/* 2. PLAYABLE GAME EXPERIENCE (MISSION 1, 2, OR 3) */}
      {(screenState === 'playing' || screenState === 'mission_complete' || screenState === 'mission_failed') && (
        <div className="relative w-full h-full">
          <MarsGameCanvas
            callbacks={callbacks}
            activeMission={activeMission}
            gameRef={gameRef}
          />

          {/* DUST STORM RED OVERLAY (MISSION 1 STAGE 5) */}
          {resources.isDustStormActive && (
            <div className="pointer-events-none absolute inset-0 z-25 bg-[radial-gradient(circle_at_center,transparent_35%,rgba(220,60,20,0.45)_95%)] storm-vignette mix-blend-color-burn" />
          )}

          {/* GROUND SHAKE OVERLAY (MISSION 2 STAGE 5) */}
          {resources.seismicTremor && (
            <div className="pointer-events-none absolute inset-0 z-25 bg-[radial-gradient(circle_at_center,transparent_40%,rgba(180,83,9,0.4)_95%)] storm-vignette" />
          )}

          {/* GAME HUD */}
          {screenState === 'playing' && !isDisasterCutsceneOpen && !isDamagedStatusOpen && (
            <HUD
              resources={resources}
              stage={stage}
              activeMission={activeMission}
              waypoint={waypoint}
              interactionPrompt={interactionPrompt}
              warningMessage={warningMessage}
              discoveredFactsCount={unlockedFactIds.length}
              totalFactsCount={NASA_FACTS.length}
              onOpenFieldGuide={() => setIsFieldGuideOpen(true)}
              onOpenPauseMenu={() => setIsPaused(true)}
            />
          )}

          {/* CHARACTER TALK OVERLAY */}
          {activeDialogue && screenState === 'playing' && !isDisasterCutsceneOpen && !isDamagedStatusOpen && (
            <DialogueOverlay
              dialogues={activeDialogue}
              onComplete={() => {
                if (
                  stage === 'cinematic_ending' ||
                  stage === 'm2_cinematic_ending' ||
                  stage === 'm3_cinematic_ending'
                ) {
                  markMissionComplete(activeMission);
                  setScreenState('mission_complete');
                }
                setActiveDialogue(null);
              }}
            />
          )}

          {/* NASA FUN FACT POPUP */}
          {activeEducationalFact && !isDisasterCutsceneOpen && !isDamagedStatusOpen && (
            <EducationalModal
              fact={activeEducationalFact}
              onClose={() => setActiveEducationalFact(null)}
            />
          )}

          {/* IN-GAME DISASTER CUTSCENE ("THE MOMENT EVERYTHING CHANGED") */}
          {isDisasterCutsceneOpen && screenState === 'playing' && (
            <DisasterCinematicModal
              onComplete={() => {
                setIsDisasterCutsceneOpen(false);
                if (stage === 'stage_0_opening_explore') {
                  setIsDamagedStatusOpen(true);
                }
              }}
            />
          )}

          {/* DAMAGED SPACECRAFT & EMERGENCY STATUS SCREEN */}
          {isDamagedStatusOpen && screenState === 'playing' && (
            <DamagedShipStatusModal
              onReplayCutscene={() => {
                setIsDamagedStatusOpen(false);
                setIsDisasterCutsceneOpen(true);
              }}
              onStartMission={() => {
                setIsDamagedStatusOpen(false);
                gameRef.current?.startPostDisasterMission?.();
              }}
            />
          )}

          {/* ROVER POWER SWITCHES (MISSION 3 STAGE 1) */}
          {isBreakerConsoleOpen && screenState === 'playing' && (
            <PowerBusConsoleModal
              onSolved={() => {
                gameRef.current?.solveBreakerTriage?.();
                setIsBreakerConsoleOpen(false);
              }}
              onClose={() => setIsBreakerConsoleOpen(false)}
            />
          )}

          {/* PAUSE MENU */}
          {isPaused && !isDisasterCutsceneOpen && !isDamagedStatusOpen && (
            <PauseMenu
              onResume={() => setIsPaused(false)}
              onRestart={handleRestartMission}
              onReturnToMenu={handleReturnToMenu}
              onOpenFieldGuide={() => {
                setIsPaused(false);
                setIsFieldGuideOpen(true);
              }}
              onReplayCutscene={
                activeMission === 'mission_1'
                  ? () => {
                      setIsPaused(false);
                      setIsDisasterCutsceneOpen(true);
                    }
                  : undefined
              }
            />
          )}
        </div>
      )}

      {/* 3. MISSION COMPLETED SCREEN */}
      {screenState === 'mission_complete' && (
        <MissionCompleteModal
          stats={missionStats}
          onReplay={handleRestartMission}
          onContinueToMission2={
            completedMissions.includes('mission_1') ? handleContinueToMission2 : undefined
          }
          onContinueToMission3={
            completedMissions.includes('mission_2') ? handleContinueToMission3 : undefined
          }
          onSelectMission={(m) => {
            if (isMissionUnlocked(m, completedMissions)) {
              handleSelectMission(m);
            } else {
              setActiveMission('mission_1');
            }
            setScreenState('menu');
          }}
          onOpenFieldGuide={() => setIsFieldGuideOpen(true)}
        />
      )}

      {/* 4. MISSION STOPPED / TRY AGAIN SCREEN */}
      {screenState === 'mission_failed' && (
        <GameOverModal
          onRestart={handleRestartMission}
          onReturnToMenu={handleReturnToMenu}
          reason={
            resources.oxygen <= 0
              ? 'Your suit air ran out before you got back to the safe base!'
              : resources.condition <= 0
              ? 'The rover bumped into too many rocks and broke!'
              : 'Something went wrong outside on Mars.'
          }
        />
      )}

      {/* 5. NASA SPACE FACTS BOOK */}
      {isFieldGuideOpen && (
        <NasaFieldGuide
          unlockedFactIds={unlockedFactIds}
          onClose={() => setIsFieldGuideOpen(false)}
        />
      )}
    </div>
  );
}
