import { DialogueLine, EducationalFact } from '../types/game';

export const NASA_FACTS: EducationalFact[] = [
  // ==================== MISSION 1 FACTS ====================
  {
    id: 'jezero_crater',
    title: 'Jezero Crater: An Old Lake on Mars',
    subtitle: 'Where NASA Sent the Perseverance Rover',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/jezero_crater.jpg',
    imageCaption: 'NASA picture of Jezero Crater on Mars.',
    nasaFact:
      'Long ago, Jezero Crater was a big lake full of water! Rivers carried mud and rocks into the lake. NASA sent the Perseverance rover here to look for signs of tiny ancient life.',
    gameContext:
      'In Mission 1, your base and broken radio tower sit on this rocky lake edge.',
    sourceName: 'NASA Mars 2020 Perseverance',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_1_leave_habitat',
    instrumentName: 'Space Orbiter Camera',
    solObservation: 'Jezero Crater',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'equipment_maintenance',
    title: 'Fixing Broken Tools on Mars',
    subtitle: 'Why Spare Parts Keep Astronauts Safe',
    category: 'ROVER TECH',
    imageSrc: '/assets/nasa/perseverance_rover.jpg',
    imageCaption: 'NASA Perseverance rover and small flying helicopter on Mars.',
    nasaFact:
      'It takes about 7 months for a rocket to bring new things from Earth to Mars! So astronauts and rovers must carry spare parts and fix broken tools right away.',
    gameContext:
      'You pick up a spare power part from the orange box so you can fix the broken radio tower.',
    sourceName: 'NASA Mars Rover Pictures',
    sourceUrl: 'https://mars.nasa.gov/mars2020/multimedia/raw-images/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_2_collect_coupler',
    instrumentName: 'Rover Camera',
    solObservation: 'Sol 46',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'space_communications',
    title: 'How Mars Talks to Earth',
    subtitle: 'Giant Radio Dishes and Space Satellites',
    category: 'COMMUNICATIONS',
    imageSrc: '/assets/nasa/deep_space_network.jpg',
    imageCaption: 'A giant NASA radio dish on Earth that listens to Mars.',
    nasaFact:
      'Mars is very far away! A radio message takes 5 to 20 minutes to travel from Mars to Earth. Rovers send messages up to satellites in space, and the satellites beam them to giant dishes on Earth.',
    gameContext:
      'Fixing the radio tower lets your base talk to Earth again!',
    sourceName: 'NASA Deep Space Network',
    sourceUrl: 'https://www.nasa.gov/directorates/somd/space-communications-navigation-program/deep-space-network/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_4_repair_relay',
    instrumentName: 'Giant Radio Dish',
    solObservation: 'Mars Radio Link',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'martian_dust_storms',
    title: 'Big Dust Storms on Mars',
    subtitle: 'Why Mars Dust Is Tricky',
    category: 'ATMOSPHERE',
    imageSrc: '/assets/nasa/mars_dust_storm.jpg',
    imageCaption: 'Mars before (left) and during (right) a giant planet dust storm.',
    nasaFact:
      'Mars has very thin air, so wind does not push hard. But Mars dust is tiny like baby powder! Big storms can block the sun, cover solar panels, and clog spacesuit air filters.',
    gameContext:
      'When the storm arrives, it gets harder to see and your spacesuit uses air twice as fast. Hurry back inside!',
    sourceName: 'NASA Mars Science',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/science/',
    missionId: 'mission_1',
    unlockedAtStage: 'stage_5_escape_storm',
    instrumentName: 'Space Telescope & Mars Camera',
    solObservation: 'Global Dust Storm',
    datasetType: 'REAL_NASA_OBSERVATION',
  },

  // ==================== MISSION 2 FACTS ====================
  {
    id: 'rimfax_subsurface_radar',
    title: 'Looking Underground with Radar',
    subtitle: 'How NASA Sees Under Mars Dirt',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/rimfax_radar.jpg',
    imageCaption: 'NASA RIMFAX radar map showing rock layers under the ground.',
    nasaFact:
      'Perseverance has a special tool called RIMFAX. It sends radio waves 10 meters down into the ground to see hidden rock layers and buried caves without digging!',
    gameContext:
      'Watch your Sensor Signal bar and listen to the beeps to find where to place the two ground sensors.',
    sourceName: 'NASA RIMFAX Radar',
    sourceUrl: 'https://mars.nasa.gov/mars2020/spacecraft/instruments/rimfax/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_1_canyon_transit',
    instrumentName: 'RIMFAX Radar',
    solObservation: 'Sol 210',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'neretva_vallis_floods',
    title: 'Neretva Valley: An Ancient River',
    subtitle: 'Carved by Rushing Water Long Ago',
    category: 'GEOLOGY',
    imageSrc: '/assets/nasa/neretva_vallis.jpg',
    imageCaption: 'A dry river valley on Mars called Neretva Vallis.',
    nasaFact:
      'Over 3 billion years ago, huge floods of water rushed through this valley and carried rocks and clay into Jezero Crater.',
    gameContext:
      'You drive into this old river valley to set up Ground Sensor 1.',
    sourceName: 'NASA Neretva Vallis',
    sourceUrl: 'https://science.nasa.gov/mission/mars-2020-perseverance/science/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_2_deploy_beacons',
    instrumentName: 'Orbiter Map',
    solObservation: 'Sol 1140',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'martian_lava_tubes',
    title: 'Underground Caves on Mars',
    subtitle: 'Safe Shelters Made by Old Volcanoes',
    category: 'SUBTERRANEAN',
    imageSrc: '/assets/nasa/mars_lava_tube.jpg',
    imageCaption: 'A hole in Mars leading down into an underground lava cave.',
    nasaFact:
      'Mars has big underground caves made by old melted lava. Their thick rock roofs protect astronauts from space rays, freezing cold, and dust storms!',
    gameContext:
      'After placing both ground sensors, drive to the cave hole to go underground.',
    sourceName: 'NASA Mars Caves',
    sourceUrl: 'https://science.nasa.gov/solar-system/planets/mars/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_3_lava_tube_entry',
    instrumentName: 'HiRISE Space Camera',
    solObservation: 'Volcanic Cave',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'sample_core_caching',
    title: 'Drilling a Mars Rock Sample',
    subtitle: 'Saving Clean Rocks in Metal Tubes',
    category: 'ROVER TECH',
    imageSrc: '/assets/nasa/sample_core_tube.jpg',
    imageCaption: 'A shiny metal tube holding a real piece of Mars rock.',
    nasaFact:
      'NASA uses a spinning drill on the rover arm to cut out finger-sized rock pieces and lock them inside super clean metal tubes to bring back to Earth.',
    gameContext:
      'Use the rock drill inside the cave to collect Rock Tube #14 before the ground starts shaking!',
    sourceName: 'NASA Mars Sample Return',
    sourceUrl: 'https://science.nasa.gov/mission/mars-sample-return/',
    missionId: 'mission_2',
    unlockedAtStage: 'm2_stage_4_sample_extraction',
    instrumentName: 'Rover Rock Drill',
    solObservation: 'Sol 194',
    datasetType: 'REAL_NASA_OBSERVATION',
  },

  // ==================== MISSION 3 FACTS ====================
  {
    id: 'sample_caching_heritage',
    title: 'Keeping Rover Power Safe from Dust',
    subtitle: 'Turning Off Broken Parts to Save Power',
    category: 'POWER SYSTEMS',
    imageSrc: '/assets/nasa/meda_weather_station.jpg',
    imageCaption: 'Rover weather and heat sensors checking Mars dust.',
    nasaFact:
      'Fine Mars dust sticks to wires and heaters. If one part breaks and wastes power, engineers turn off extra tools so the rover still has enough power to drive safely.',
    gameContext:
      'Turn off the broken heater switch and set the rock scanner to sleep so the rover stays under 400W!',
    sourceName: 'NASA MEDA Sensors',
    sourceUrl: 'https://mars.nasa.gov/mars2020/spacecraft/instruments/meda/',
    missionId: 'mission_3',
    unlockedAtStage: 'm3_stage_1_grid_triage',
    instrumentName: 'Power & Dust Sensors',
    solObservation: 'Sol 249',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
  {
    id: 'mars_ascent_vehicle',
    title: 'Launching a Rocket from Mars!',
    subtitle: 'Flying Rock Samples Back to Earth',
    category: 'NAVIGATION',
    imageSrc: '/assets/nasa/perseverance_rover.jpg',
    imageCaption: 'NASA plan to launch Mars rock tubes into space to meet a ship going to Earth.',
    nasaFact:
      'A Mars Rocket has two stages. Stage 1 pushes the rocket high into the sky and drops off. Then Stage 2 flies fast into space to meet the spaceship waiting to go back to Earth!',
    gameContext:
      'Load the rock tube into the Mars Rocket, steer with A and D, press SPACE to drop Stage 1, and dock with the spaceship!',
    sourceName: 'NASA Mars Sample Return',
    sourceUrl: 'https://science.nasa.gov/mission/mars-sample-return/',
    missionId: 'mission_3',
    unlockedAtStage: 'm3_stage_4_mav_ascent',
    instrumentName: 'Mars Rocket',
    solObservation: 'Return Flight',
    datasetType: 'REAL_NASA_OBSERVATION',
  },
];

export const DIALOGUE_SCRIPTS: Record<string, DialogueLine[]> = {
  // ==================== MISSION 1 DIALOGUES ====================
  opening_explore: [
    {
      id: 'op_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'We landed safely on Mars! Look how quiet and red everything is out here.',
    },
    {
      id: 'op_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Walk over to the glowing blue circle next to our ship and press E to run a quick check!',
    },
  ],
  stage1_exit: [
    {
      id: 's1_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'That explosion broke our main return rocket and knocked out our Earth radio!',
    },
    {
      id: 's1_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'We must fix the radio tower on the hill so Earth can help us find a new way home! Stand in the green circle anytime to fill your suit air.',
    },
    {
      id: 's1_3',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'I am ready! First, I will walk to the orange box and press E to grab the spare power part.',
    },
  ],
  stage2_crate: [
    {
      id: 's2_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Awesome! I got the power part! Now I will go to the rover and press E to drive it.',
    },
  ],
  stage3_rover_enter: [
    {
      id: 's3_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Nice driving! Be careful around the big rocks. Hitting rocks hurts the rover!',
    },
    {
      id: 's3_2',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'I will steer carefully and follow the yellow arrow to the radio tower!',
    },
  ],
  stage4_repaired: [
    {
      id: 's4_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Done! The new part is in, and the radio dish is spinning!',
    },
    {
      id: 's4_2',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Earth can hear us again! Great job, Hazaloom!',
    },
  ],
  stage5_storm_alert: [
    {
      id: 's5_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Watch out! The dust storm is here! It is hard to see and your suit uses air faster now!',
    },
    {
      id: 's5_2',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'I see the dust! Driving back to the safe base right now!',
    },
  ],
  ending: [
    {
      id: 'end_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'You made it back inside safe and sound, Hazaloom! The storm cannot hurt us in here.',
    },
    {
      id: 'end_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Mission 1 is complete! Mission 2 is now unlocked so we can explore the old river valley!',
    },
  ],

  // ==================== MISSION 2 DIALOGUES ====================
  m2_stage1_start: [
    {
      id: 'm2_s1_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Welcome to the old river valley, Hazaloom! Let us find hidden caves underground.',
    },
    {
      id: 'm2_s1_2',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Get in the rover with E, follow the yellow arrow, and press E at the circle to drop Ground Sensor 1.',
    },
  ],
  m2_beacon1_placed: [
    {
      id: 'm2_b1_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Ground Sensor 1 is in place and beeping!',
    },
    {
      id: 'm2_b1_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Great! Now drive north to drop Ground Sensor 2 so we can find the underground cave.',
    },
  ],
  m2_beacon2_placed: [
    {
      id: 'm2_b2_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Both sensors work! Look—our map found a huge underground lava cave nearby!',
    },
    {
      id: 'm2_b2_2',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Awesome! I will drive to the cave hole and go inside!',
    },
  ],
  m2_cave_entry: [
    {
      id: 'm2_ce_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Whoa, it is dark inside this cave! Good thing the rover has bright headlights.',
    },
    {
      id: 'm2_ce_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Drive carefully past the pointy rocks to the glowing blue crystal, then press E to drill a rock sample!',
    },
  ],
  m2_sample_drilled: [
    {
      id: 'm2_sd_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Got it! Rock Tube #14 is safely packed!',
    },
  ],
  m2_tremor_alert: [
    {
      id: 'm2_ta_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'WHOA! A Mars ground shake just started! The cave roof is shaking!',
    },
    {
      id: 'm2_ta_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Turn around fast, Hazaloom! Drive back to the blue cave exit circle right now!',
    },
  ],
  m2_ending: [
    {
      id: 'm2_end_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'Phew! Made it out of the cave with Rock Tube #14!',
    },
    {
      id: 'm2_end_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Amazing job! Mission 3 is now unlocked—time to launch our rocket home!',
    },
  ],

  // ==================== MISSION 3 DIALOGUES ====================
  m3_stage1_start: [
    {
      id: 'm3_s1_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Uh oh! Dust broke Heater #2 on our rover, and it is wasting too much power!',
    },
    {
      id: 'm3_s1_2',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Walk to the rover and press E to open the power switches. Turn off the broken heater and rock scanner!',
    },
  ],
  m3_bus_isolated: [
    {
      id: 'm3_bi_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'Nice! Power is safe now! Drive east to the Mars Rocket pad, and watch out for spinning dust tornadoes!',
    },
  ],
  m3_dust_devil_hit: [
    {
      id: 'm3_dd_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'Oops! That spinning dust tornado drained some rover battery. Try to steer around them!',
    },
  ],
  m3_mav_reached: [
    {
      id: 'm3_mr_1',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'There is the Mars Rocket! Let us go to the yellow circle and press E to climb on board!',
    },
  ],
  m3_launch_ignited: [
    {
      id: 'm3_li_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: '3... 2... 1... BLAST OFF! Use A and D (or Left and Right arrows) to keep the white line inside the green box!',
    },
  ],
  m3_stage1_burnout: [
    {
      id: 'm3_sb_1',
      speaker: 'HEDEYA',
      characterId: 'hedeya',
      callsign: 'FIX-IT ENGINEER',
      text: 'First rocket tank is empty! Press SPACEBAR to drop it and fire the second rocket!',
    },
  ],
  m3_orbital_dock: [
    {
      id: 'm3_od_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'We made it to space! Use WASD or Arrow keys to steer the rocket gently into the spaceship center ring!',
    },
  ],
  m3_ending: [
    {
      id: 'm3_end_1',
      speaker: 'SAMANTHA',
      characterId: 'samantha',
      callsign: 'SPACE SCIENTIST',
      text: 'CLICK! We docked safely! Our Mars rock sample is ready to go back to Earth!',
    },
    {
      id: 'm3_end_2',
      speaker: 'HAZALOOM',
      characterId: 'hazaloom',
      callsign: 'ASTRONAUT (YOU)',
      text: 'We beat all three Mars missions together! Thank you for flying with us! Next stop: Home!',
    },
  ],
};
