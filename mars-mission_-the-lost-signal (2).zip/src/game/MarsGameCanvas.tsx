import React, { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import { Mission1Scene, SceneCallbacks } from './scenes/Mission1Scene';
import { Mission2Scene } from './scenes/Mission2Scene';
import { Mission3Scene } from './scenes/Mission3Scene';
import { MissionId } from '../types/game';

interface MarsGameCanvasProps {
  callbacks: SceneCallbacks;
  activeMission: MissionId;
  gameRef: React.MutableRefObject<{
    resetMission: () => void;
    solveBreakerTriage?: () => void;
    startPostDisasterMission?: () => void;
  } | null>;
}

export const MarsGameCanvas: React.FC<MarsGameCanvasProps> = ({
  callbacks,
  activeMission,
  gameRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const phaserInstanceRef = useRef<Phaser.Game | null>(null);
  const callbacksRef = useRef<SceneCallbacks>(callbacks);

  useEffect(() => {
    callbacksRef.current = callbacks;
  }, [callbacks]);

  useEffect(() => {
    if (!containerRef.current) return;

    const stableCallbacks: SceneCallbacks = {
      onResourceUpdate: (res) => callbacksRef.current.onResourceUpdate(res),
      onStageChange: (stage) => callbacksRef.current.onStageChange(stage),
      onPromptChange: (prompt) => callbacksRef.current.onPromptChange(prompt),
      onDialogueTrigger: (key) => callbacksRef.current.onDialogueTrigger(key),
      onFactUnlock: (factId) => callbacksRef.current.onFactUnlock(factId),
      onWarning: (msg) => callbacksRef.current.onWarning(msg),
      onWaypointUpdate: (wp) => callbacksRef.current.onWaypointUpdate(wp),
      onMissionEnd: (success) => callbacksRef.current.onMissionEnd(success),
      onOpenBreakerConsole: () => callbacksRef.current.onOpenBreakerConsole?.(),
      onTriggerDisasterCinematic: () => callbacksRef.current.onTriggerDisasterCinematic?.(),
    };

    const TargetSceneClass =
      activeMission === 'mission_3'
        ? Mission3Scene
        : activeMission === 'mission_2'
        ? Mission2Scene
        : Mission1Scene;

    const targetSceneKey =
      activeMission === 'mission_3'
        ? 'Mission3Scene'
        : activeMission === 'mission_2'
        ? 'Mission2Scene'
        : 'Mission1Scene';

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      parent: containerRef.current,
      width: window.innerWidth,
      height: window.innerHeight,
      pixelArt: false,
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { x: 0, y: 0 },
          debug: false,
        },
      },
      scale: {
        mode: Phaser.Scale.RESIZE,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
      backgroundColor: '#0c0706',
      // Only register the active mission's scene so Phaser never auto-boots Mission1Scene without data
      scene: [TargetSceneClass],
    };

    const game = new Phaser.Game(config);
    phaserInstanceRef.current = game;

    // Pass callbacks data to the active scene before bootQueue starts it
    game.scene.start(targetSceneKey, { callbacks: stableCallbacks });

    // Store scene instance for external resets & interactive bridge actions
    game.events.once('step', () => {
      const activeScene = game.scene.getScene(targetSceneKey) as
        | Mission1Scene
        | Mission2Scene
        | Mission3Scene;
      if (gameRef) {
        gameRef.current = {
          resetMission: () => {
            activeScene?.resetMission();
          },
          solveBreakerTriage: () => {
            if (activeScene && 'toggleBreakerTriage' in activeScene) {
              activeScene.toggleBreakerTriage();
            }
          },
          startPostDisasterMission: () => {
            if (activeScene && 'startPostDisasterMission' in activeScene) {
              activeScene.startPostDisasterMission();
            }
          },
        };
      }
    });

    const handleResize = () => {
      if (phaserInstanceRef.current) {
        phaserInstanceRef.current.scale.resize(window.innerWidth, window.innerHeight);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      game.destroy(true);
    };
  }, [activeMission]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full overflow-hidden select-none"
      style={{ touchAction: 'none' }}
    />
  );
};
