import Phaser from 'phaser';

/**
 * Procedural pixel-art and vector texture generator for Phaser 3
 * Generates high-quality Mars mission sprites directly into the game texture cache.
 */
export function generateMarsTextures(scene: Phaser.Scene) {
  // 1. Martian Regolith Ground Texture (64x64 repeatable)
  if (!scene.textures.exists('martian_ground')) {
    const canvas = scene.textures.createCanvas('martian_ground', 128, 128);
    if (canvas) {
      const ctx = canvas.getContext();
      ctx.fillStyle = '#b44a2c'; // Base Mars rust orange
      ctx.fillRect(0, 0, 128, 128);

      // Subtle texture variation & pebbles
      for (let i = 0; i < 220; i++) {
        const x = Math.random() * 128;
        const y = Math.random() * 128;
        const radius = Math.random() * 1.8 + 0.5;
        const colorVal = Math.random() > 0.5 ? '#94381e' : '#c85a38';
        ctx.fillStyle = colorVal;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Small crater ripples
      ctx.strokeStyle = 'rgba(70, 20, 10, 0.25)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(36, 42, 14, 0.2, 2.5);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(95, 88, 10, 0.3, 2.8);
      ctx.stroke();

      canvas.refresh();
    }
  }

  // 2. Rough Sand Dune / Loose Regolith Tile (128x128)
  if (!scene.textures.exists('rough_dunes')) {
    const canvas = scene.textures.createCanvas('rough_dunes', 128, 128);
    if (canvas) {
      const ctx = canvas.getContext();
      ctx.fillStyle = '#8e351b'; // Darker sandy dune
      ctx.fillRect(0, 0, 128, 128);

      // Dune wind ripples
      ctx.strokeStyle = 'rgba(215, 100, 60, 0.4)';
      ctx.lineWidth = 3;
      for (let y = 15; y < 128; y += 22) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.bezierCurveTo(35, y - 8, 85, y + 8, 128, y);
        ctx.stroke();
      }

      // Darker ripple shadows
      ctx.strokeStyle = 'rgba(50, 15, 8, 0.35)';
      ctx.lineWidth = 2;
      for (let y = 18; y < 128; y += 22) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.bezierCurveTo(35, y - 6, 85, y + 10, 128, y);
        ctx.stroke();
      }

      canvas.refresh();
    }
  }

  // 3. Astronaut Sprite (48x48)
  if (!scene.textures.exists('astronaut')) {
    const canvas = scene.textures.createCanvas('astronaut', 48, 48);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 24;
      const cy = 24;

      // Soft shadow
      ctx.fillStyle = 'rgba(40, 15, 10, 0.5)';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 4, 18, 12, 0, 0, Math.PI * 2);
      ctx.fill();

      // Life support backpack (PLSS)
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(cx - 10, cy - 14, 20, 10);
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1;
      ctx.strokeRect(cx - 10, cy - 14, 20, 10);

      // Oxygen connector tubes
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - 6, cy - 14);
      ctx.lineTo(cx - 6, cy - 6);
      ctx.stroke();

      // Suit body (torso and shoulders)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 2, 14, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Mission orange shoulder patches
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(cx - 15, cy - 1, 3, 6);
      ctx.fillRect(cx + 12, cy - 1, 3, 6);

      // Helmet (white sphere)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx, cy + 5, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Golden reflective visor (facing downwards by default)
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(cx, cy + 7, 7, 0, Math.PI);
      ctx.fill();

      // Visor highlight reflection
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx - 2, cy + 8, 2, 0, Math.PI * 2);
      ctx.fill();

      canvas.refresh();
    }
  }

  // 4. Mars Exploration Rover (64x96)
  if (!scene.textures.exists('rover')) {
    const canvas = scene.textures.createCanvas('rover', 72, 100);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 36;
      const cy = 50;

      // Drop shadow
      ctx.fillStyle = 'rgba(30, 10, 5, 0.55)';
      ctx.beginPath();
      ctx.roundRect(cx - 30, cy - 42, 60, 84, 10);
      ctx.fill();

      // 6 Heavy-duty aluminum wheels (cleats)
      const wheelPositions = [
        { x: cx - 28, y: cy - 32 }, // Front-left
        { x: cx + 28, y: cy - 32 }, // Front-right
        { x: cx - 30, y: cy },      // Mid-left
        { x: cx + 30, y: cy },      // Mid-right
        { x: cx - 28, y: cy + 32 }, // Rear-left
        { x: cx + 28, y: cy + 32 }, // Rear-right
      ];

      wheelPositions.forEach((pos) => {
        // Wheel rubber/metal
        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.roundRect(pos.x - 5, pos.y - 10, 10, 20, 3);
        ctx.fill();
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Cleat treads
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.5;
        for (let dy = -6; dy <= 6; dy += 4) {
          ctx.beginPath();
          ctx.moveTo(pos.x - 4, pos.y + dy);
          ctx.lineTo(pos.x + 4, pos.y + dy);
          ctx.stroke();
        }

        // Suspension bogie arm
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(cx, cy);
        ctx.stroke();
      });

      // Main Rover Chassis Deck
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.roundRect(cx - 20, cy - 34, 40, 68, 6);
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Gold Multi-Layer Insulation (MLI) blanket section
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(cx - 16, cy - 8, 32, 22);
      ctx.strokeStyle = '#b45309';
      ctx.lineWidth = 1;
      ctx.strokeRect(cx - 16, cy - 8, 32, 22);

      // Solar Panel / Equipment Grid
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(cx - 15, cy - 30, 30, 18);
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 1;
      ctx.strokeRect(cx - 15, cy - 30, 30, 18);
      // Grid lines
      ctx.beginPath();
      ctx.moveTo(cx, cy - 30);
      ctx.lineTo(cx, cy - 12);
      ctx.moveTo(cx - 15, cy - 21);
      ctx.lineTo(cx + 15, cy - 21);
      ctx.stroke();

      // Mastcam-Z Sensor Tower (forward facing)
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.arc(cx, cy - 32, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Dual High-Intensity Headlights
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(cx - 12, cy - 34, 3.5, 0, Math.PI * 2);
      ctx.arc(cx + 12, cy - 34, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // RTG (Radioisotope Thermoelectric Generator) cylinder at rear
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.roundRect(cx - 8, cy + 18, 16, 12, 3);
      ctx.fill();
      ctx.strokeStyle = '#dc2626'; // Red thermal warning strip
      ctx.lineWidth = 2;
      ctx.stroke();

      canvas.refresh();
    }
  }

  // 5. Basalt Boulders (3 variations: rock_1, rock_2, rock_3)
  const rockConfigs = [
    { key: 'rock_1', w: 60, h: 50, points: [[12, 10], [42, 8], [55, 26], [45, 44], [16, 46], [6, 30]] },
    { key: 'rock_2', w: 75, h: 65, points: [[18, 12], [54, 10], [70, 34], [58, 58], [22, 60], [8, 38]] },
    { key: 'rock_3', w: 45, h: 40, points: [[10, 8], [34, 6], [42, 22], [32, 36], [12, 36], [4, 20]] },
  ];

  rockConfigs.forEach((rock) => {
    if (!scene.textures.exists(rock.key)) {
      const canvas = scene.textures.createCanvas(rock.key, rock.w, rock.h);
      if (canvas) {
        const ctx = canvas.getContext();

        // Shadow
        ctx.fillStyle = 'rgba(25, 8, 4, 0.6)';
        ctx.beginPath();
        ctx.ellipse(rock.w / 2, rock.h / 2 + 4, rock.w / 2 - 4, rock.h / 2 - 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Dark basalt body
        ctx.fillStyle = '#3f3f46';
        ctx.beginPath();
        rock.points.forEach(([px, py], idx) => {
          if (idx === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        });
        ctx.closePath();
        ctx.fill();

        // Edge highlights (sunlit side)
        ctx.strokeStyle = '#71717a';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Dust coating on top surfaces
        ctx.fillStyle = 'rgba(180, 74, 44, 0.45)';
        ctx.beginPath();
        ctx.moveTo(rock.points[0][0], rock.points[0][1]);
        ctx.lineTo(rock.points[1][0], rock.points[1][1]);
        ctx.lineTo(rock.w / 2, rock.h / 2);
        ctx.closePath();
        ctx.fill();

        canvas.refresh();
      }
    }
  });

  // 6. Habitat Module (180x180)
  if (!scene.textures.exists('habitat_base')) {
    const canvas = scene.textures.createCanvas('habitat_base', 180, 180);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 90;
      const cy = 90;

      // Soft ground ambient occlusion
      ctx.fillStyle = 'rgba(30, 10, 5, 0.45)';
      ctx.beginPath();
      ctx.arc(cx, cy, 84, 0, Math.PI * 2);
      ctx.fill();

      // Main inflatable habitat dome (white geodesic pressurized shell)
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.arc(cx, cy, 65, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Inner structural rings
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, 45, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(cx, cy, 25, 0, Math.PI * 2);
      ctx.stroke();

      // Central Cupola Observation Window
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Airlock Module (facing southwards towards x=90, y=160)
      ctx.fillStyle = '#475569';
      ctx.fillRect(cx - 18, cy + 45, 36, 32);
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 2;
      ctx.strokeRect(cx - 18, cy + 45, 36, 32);

      // Safe Zone Green LED Airlock Seal
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(cx - 12, cy + 68, 24, 6);

      // Habitat Markings
      ctx.fillStyle = '#ef4444';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SAFE BASE', cx, cy - 48);

      canvas.refresh();
    }
  }

  // 7. Supply Crate (44x44)
  if (!scene.textures.exists('supply_crate')) {
    const canvas = scene.textures.createCanvas('supply_crate', 44, 44);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 22;
      const cy = 22;

      // Shadow
      ctx.fillStyle = 'rgba(30, 10, 5, 0.5)';
      ctx.beginPath();
      ctx.roundRect(4, 6, 36, 34, 4);
      ctx.fill();

      // Outer crate body
      ctx.fillStyle = '#ea580c'; // High-visibility hazard orange
      ctx.beginPath();
      ctx.roundRect(4, 4, 36, 34, 4);
      ctx.fill();
      ctx.strokeStyle = '#fdba74';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Corner reinforced metal brackets
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(4, 4, 8, 8);
      ctx.fillRect(32, 4, 8, 8);
      ctx.fillRect(4, 30, 8, 8);
      ctx.fillRect(32, 30, 8, 8);

      // Pulsing cyan status beacon in center
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // NASA stencil
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 7px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SPARE', cx, cy + 14);

      canvas.refresh();
    }
  }

  // 8. Communications Relay Tower (80x80)
  if (!scene.textures.exists('relay_tower')) {
    const canvas = scene.textures.createCanvas('relay_tower', 90, 90);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 45;
      const cy = 45;

      // Shadow
      ctx.fillStyle = 'rgba(20, 8, 4, 0.5)';
      ctx.beginPath();
      ctx.ellipse(cx + 8, cy + 12, 34, 20, 0, 0, Math.PI * 2);
      ctx.fill();

      // Concrete / Foundation Hex Pad
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI) / 3;
        const hx = cx + Math.cos(angle) * 36;
        const hy = cy + Math.sin(angle) * 36;
        if (i === 0) ctx.moveTo(hx, hy);
        else ctx.lineTo(hx, hy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Truss legs
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(cx - 26, cy + 22);
      ctx.lineTo(cx, cy);
      ctx.moveTo(cx + 26, cy + 22);
      ctx.lineTo(cx, cy);
      ctx.moveTo(cx, cy - 26);
      ctx.lineTo(cx, cy);
      ctx.stroke();

      // Parabolic Satellite Dish (facing northeast)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 4, 24, 16, Math.PI / 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Central Feed Horn
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(cx + 4, cy - 6, 4, 0, Math.PI * 2);
      ctx.fill();

      // Status LED indicator
      ctx.fillStyle = '#ef4444'; // Red until repaired
      ctx.beginPath();
      ctx.arc(cx - 20, cy + 20, 4, 0, Math.PI * 2);
      ctx.fill();

      canvas.refresh();
    }
  }

  // 9. Dust storm particle
  if (!scene.textures.exists('dust_particle')) {
    const canvas = scene.textures.createCanvas('dust_particle', 8, 8);
    if (canvas) {
      const ctx = canvas.getContext();
      ctx.fillStyle = 'rgba(234, 88, 12, 0.7)';
      ctx.beginPath();
      ctx.arc(4, 4, 3, 0, Math.PI * 2);
      ctx.fill();
      canvas.refresh();
    }
  }

  // 10. Headlight Beam Texture (200x240)
  if (!scene.textures.exists('headlight_cone')) {
    const canvas = scene.textures.createCanvas('headlight_cone', 160, 240);
    if (canvas) {
      const ctx = canvas.getContext();
      const grad = ctx.createRadialGradient(80, 20, 10, 80, 120, 140);
      grad.addColorStop(0, 'rgba(254, 240, 138, 0.45)');
      grad.addColorStop(0.6, 'rgba(254, 240, 138, 0.15)');
      grad.addColorStop(1, 'rgba(254, 240, 138, 0)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(80, 10);
      ctx.lineTo(10, 240);
      ctx.lineTo(150, 240);
      ctx.closePath();
      ctx.fill();
      canvas.refresh();
    }
  }

  // 11. Mission 2: Subterranean Lava Tube Basalt Floor (128x128)
  if (!scene.textures.exists('subsurface_rock')) {
    const canvas = scene.textures.createCanvas('subsurface_rock', 128, 128);
    if (canvas) {
      const ctx = canvas.getContext();
      ctx.fillStyle = '#1c1917'; // Dark charcoal obsidian basalt
      ctx.fillRect(0, 0, 128, 128);

      // Jagged volcanic cooled lava flow veins
      ctx.strokeStyle = '#292524';
      ctx.lineWidth = 2.5;
      for (let y = 10; y < 128; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(40, y + 6);
        ctx.lineTo(85, y - 4);
        ctx.lineTo(128, y + 2);
        ctx.stroke();
      }

      // Pyroxene and olivine mineral specks
      for (let i = 0; i < 90; i++) {
        const x = Math.random() * 128;
        const y = Math.random() * 128;
        ctx.fillStyle = Math.random() > 0.6 ? '#44403c' : '#047857'; // Faint green olivine
        ctx.fillRect(x, y, 1.5, 1.5);
      }

      canvas.refresh();
    }
  }

  // 12. Mission 2: Collapsed Lava Tube Skylight Portal (160x160)
  if (!scene.textures.exists('lava_skylight')) {
    const canvas = scene.textures.createCanvas('lava_skylight', 160, 160);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 80;
      const cy = 80;

      // Outer collapsed rim with fracture lines
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.ellipse(cx, cy, 76, 56, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Deep dark cavern abyss
      ctx.fillStyle = '#09090b';
      ctx.beginPath();
      ctx.ellipse(cx, cy, 64, 46, 0, 0, Math.PI * 2);
      ctx.fill();

      // Subterranean glowing ramp indicator
      ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
      ctx.beginPath();
      ctx.moveTo(cx - 20, cy + 20);
      ctx.lineTo(cx + 20, cy + 20);
      ctx.lineTo(cx + 8, cy - 20);
      ctx.lineTo(cx - 8, cy - 20);
      ctx.closePath();
      ctx.fill();

      // Hazard hatch markings
      ctx.fillStyle = '#f59e0b';
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('CAVE HOLE // GO DOWN', cx, cy - 36);

      canvas.refresh();
    }
  }

  // 13. Mission 2: Seismic Resonance Beacon (40x40)
  if (!scene.textures.exists('seismic_beacon')) {
    const canvas = scene.textures.createCanvas('seismic_beacon', 40, 40);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 20;
      const cy = 20;

      // Tripod legs
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(cx, cy - 4);
      ctx.lineTo(cx - 12, cy + 14);
      ctx.moveTo(cx, cy - 4);
      ctx.lineTo(cx + 12, cy + 14);
      ctx.moveTo(cx, cy - 4);
      ctx.lineTo(cx, cy + 16);
      ctx.stroke();

      // Center sensor pod
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(cx, cy - 4, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Pulsing telemetry mast
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy - 12);
      ctx.lineTo(cx, cy - 18);
      ctx.stroke();

      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(cx, cy - 18, 2.5, 0, Math.PI * 2);
      ctx.fill();

      canvas.refresh();
    }
  }

  // 14. Mission 2: Anomaly Relic (Precursor Probe / Transponder) (56x56)
  if (!scene.textures.exists('anomaly_relic')) {
    const canvas = scene.textures.createCanvas('anomaly_relic', 64, 64);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 32;
      const cy = 32;

      // Outer mysterious metallic impact ring
      ctx.fillStyle = 'rgba(6, 182, 212, 0.2)';
      ctx.beginPath();
      ctx.arc(cx, cy, 28, 0, Math.PI * 2);
      ctx.fill();

      // Hexagonal metallic alloy chassis
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI) / 3;
        const x = cx + Math.cos(angle) * 22;
        const y = cy + Math.sin(angle) * 22;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Gold thermal foil MLI segments
      ctx.fillStyle = '#d97706';
      ctx.fillRect(cx - 10, cy - 14, 20, 8);
      ctx.fillRect(cx - 10, cy + 6, 20, 8);

      // Glowing Cyan Anomaly Power Core
      const coreGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 12);
      coreGrad.addColorStop(0, '#ffffff');
      coreGrad.addColorStop(0.5, '#22d3ee');
      coreGrad.addColorStop(1, 'rgba(6, 182, 212, 0)');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, 12, 0, Math.PI * 2);
      ctx.fill();

      // High-gain antenna spike
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy - 22);
      ctx.lineTo(cx, cy - 30);
      ctx.stroke();

      canvas.refresh();
    }
  }

  // 15. Mission 2: Spiky Basalt Stalactite (44x50)
  if (!scene.textures.exists('stalactite_rock')) {
    const canvas = scene.textures.createCanvas('stalactite_rock', 48, 52);
    if (canvas) {
      const ctx = canvas.getContext();
      ctx.fillStyle = '#27272a';
      ctx.beginPath();
      ctx.moveTo(24, 4);
      ctx.lineTo(44, 20);
      ctx.lineTo(34, 48);
      ctx.lineTo(14, 46);
      ctx.lineTo(4, 22);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = '#52525b';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Volcanic glass reflection
      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.beginPath();
      ctx.moveTo(24, 8);
      ctx.lineTo(32, 22);
      ctx.lineTo(24, 40);
      ctx.closePath();
      ctx.fill();

      canvas.refresh();
    }
  }

  // 16. Mission 3: Mars Ascent Vehicle (MAV) on Launch Pad (120x160)
  if (!scene.textures.exists('mav_rocket')) {
    const canvas = scene.textures.createCanvas('mav_rocket', 80, 140);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 40;
      const cy = 70;

      // Drop shadow
      ctx.fillStyle = 'rgba(20, 5, 5, 0.5)';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 50, 30, 12, 0, 0, Math.PI * 2);
      ctx.fill();

      // Stage 1 Solid Rocket Motor Body (White & Gold MLI)
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(cx - 16, cy - 10, 32, 50);
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 2;
      ctx.strokeRect(cx - 16, cy - 10, 32, 50);

      // Gold insulation blanket bands
      ctx.fillStyle = '#d97706';
      ctx.fillRect(cx - 16, cy + 10, 32, 12);
      ctx.strokeStyle = '#92400e';
      ctx.strokeRect(cx - 16, cy + 10, 32, 12);

      // 4 Aerodynamic Grid Fins
      ctx.fillStyle = '#334155';
      ctx.fillRect(cx - 24, cy + 28, 8, 14);
      ctx.fillRect(cx + 16, cy + 28, 8, 14);

      // Stage 1 Rocket Exhaust Nozzle
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(cx - 12, cy + 40);
      ctx.lineTo(cx + 12, cy + 40);
      ctx.lineTo(cx + 16, cy + 54);
      ctx.lineTo(cx - 16, cy + 54);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.stroke();

      // Interstage Separation Ring (Carbon composite)
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(cx - 15, cy - 16, 30, 6);

      // Stage 2 Hypergolic Upper Stage & Avionics
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(cx - 14, cy - 42, 28, 26);
      ctx.strokeStyle = '#64748b';
      ctx.strokeRect(cx - 14, cy - 42, 28, 26);

      // NASA Meatball & Ares insignia marking
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(cx, cy - 30, 4, 0, Math.PI * 2);
      ctx.fill();

      // Conical Nose Cone (Aero fairing housing Sample Cache Carousel)
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.moveTo(cx - 14, cy - 42);
      ctx.lineTo(cx, cy - 64);
      ctx.lineTo(cx + 14, cy - 42);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.stroke();

      // Tip probe antenna
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy - 64);
      ctx.lineTo(cx, cy - 72);
      ctx.stroke();

      canvas.refresh();
    }
  }

  // 17. Mission 3: MAV Launch Pad Gantry (180x180)
  if (!scene.textures.exists('mav_launchpad')) {
    const canvas = scene.textures.createCanvas('mav_launchpad', 180, 180);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 90;
      const cy = 90;

      // Heavy octagonal blast trench foundation
      ctx.fillStyle = '#18181b';
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const angle = (i * Math.PI) / 4 + Math.PI / 8;
        const x = cx + Math.cos(angle) * 80;
        const y = cy + Math.sin(angle) * 80;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Flame deflector grate
      ctx.fillStyle = '#09090b';
      ctx.beginPath();
      ctx.arc(cx, cy, 40, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#3f3f46';
      ctx.lineWidth = 2;
      for (let i = -35; i <= 35; i += 10) {
        ctx.moveTo(cx + i, cy - 30);
        ctx.lineTo(cx + i, cy + 30);
      }
      ctx.stroke();

      // Service umbilical umbilical tower
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(cx + 42, cy - 60, 12, 110);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.strokeRect(cx + 42, cy - 60, 12, 110);

      // Swing arm gantry
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(cx, cy - 36, 46, 8);

      // Floodlight beams
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(cx - 55, cy - 55, 5, 0, Math.PI * 2);
      ctx.arc(cx + 55, cy - 55, 5, 0, Math.PI * 2);
      ctx.fill();

      // Staging bay markings
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('MARS ROCKET PAD', cx, cy + 68);

      canvas.refresh();
    }
  }

  // 18. Mission 3: Martian Dust Devil (80x80 animated swirling vortex)
  if (!scene.textures.exists('dust_devil')) {
    const canvas = scene.textures.createCanvas('dust_devil', 80, 80);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 40;
      const cy = 40;

      // Swirling spiral vortex
      ctx.strokeStyle = 'rgba(234, 88, 12, 0.45)';
      ctx.lineWidth = 3;
      for (let r = 8; r < 36; r += 6) {
        ctx.beginPath();
        ctx.arc(cx, cy, r, Math.PI * 0.2, Math.PI * 1.6);
        ctx.stroke();
      }

      ctx.strokeStyle = 'rgba(249, 115, 22, 0.7)';
      ctx.lineWidth = 2;
      for (let r = 12; r < 34; r += 7) {
        ctx.beginPath();
        ctx.arc(cx, cy, r, Math.PI * 1.1, Math.PI * 2.3);
        ctx.stroke();
      }

      // Eye of the vortex
      ctx.fillStyle = 'rgba(254, 215, 170, 0.6)';
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();

      canvas.refresh();
    }
  }

  // 19. Mission 3: Earth Return Orbiter (ERO) in Mars Orbit (140x90)
  if (!scene.textures.exists('earth_return_orbiter')) {
    const canvas = scene.textures.createCanvas('earth_return_orbiter', 160, 100);
    if (canvas) {
      const ctx = canvas.getContext();
      const cx = 80;
      const cy = 50;

      // Central avionics bus
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.roundRect(cx - 24, cy - 16, 48, 32, 4);
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Gold thermal foil covering
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(cx - 18, cy - 10, 36, 20);

      // Docking mechanism & guide collar (target for MAV)
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.stroke();

      // Crosshair laser target in docking port
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 10, cy);
      ctx.lineTo(cx + 10, cy);
      ctx.moveTo(cx, cy - 10);
      ctx.lineTo(cx, cy + 10);
      ctx.stroke();

      // Left Giant Solar Array Wing (Blue silicon cells)
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(cx - 72, cy - 14, 44, 28);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(cx - 72, cy - 14, 44, 28);
      // Grid lines
      for (let x = cx - 62; x < cx - 28; x += 10) {
        ctx.beginPath();
        ctx.moveTo(x, cy - 14);
        ctx.lineTo(x, cy + 14);
        ctx.stroke();
      }

      // Right Giant Solar Array Wing
      ctx.fillStyle = '#1e3a8a';
      ctx.fillRect(cx + 28, cy - 14, 44, 28);
      ctx.strokeStyle = '#38bdf8';
      ctx.strokeRect(cx + 28, cy - 14, 44, 28);
      for (let x = cx + 38; x < cx + 72; x += 10) {
        ctx.beginPath();
        ctx.moveTo(x, cy - 14);
        ctx.lineTo(x, cy + 14);
        ctx.stroke();
      }

      // High-gain communications dish
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx, cy - 24, 10, 0, Math.PI, true);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.stroke();

      canvas.refresh();
    }
  }

  // 20. Mission 3: Rocket Plume Particles
  if (!scene.textures.exists('rocket_flame')) {
    const canvas = scene.textures.createCanvas('rocket_flame', 24, 24);
    if (canvas) {
      const ctx = canvas.getContext();
      const grad = ctx.createRadialGradient(12, 12, 2, 12, 12, 11);
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(0.3, '#fde047');
      grad.addColorStop(0.7, '#ea580c');
      grad.addColorStop(1, 'rgba(239, 68, 68, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(12, 12, 11, 0, Math.PI * 2);
      ctx.fill();
      canvas.refresh();
    }
  }
}
