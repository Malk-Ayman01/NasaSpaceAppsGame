# Mars Mission: Jezero Crater Expeditions
### 2D Top-Down Mars Exploration & Survival Simulator (Phaser 3 + React)

Inspired by **GTA V mission architecture**, narrative choice, and authentic **NASA Perseverance, RIMFAX & Jezero Crater scientific data**.

---

## 🚀 Game Overview

The year is 2038. The human Mars exploration program has established the **Ares-1 Research Base** inside Jezero Crater—the same ancient river delta explored by NASA's Perseverance rover.

You command **Commander Alex Vance** across two linked campaign acts:
- **Mission 1: The Lost Signal** — Restore the damaged high-frequency communications relay tower and outrun an approaching planetary dust storm.
- **Mission 2: The Anomaly (ACT II)** — Track a mysterious subterranean carrier pulse into the ancient flood channels of Neretva Vallis, anchor seismic resonance beacons, explore a subterranean volcanic lava tube, and drill a pristine core sample before a violent crustal Marsquake triggers a catastrophic cave-in.

---

## 🎮 Campaign Walkthroughs

### 🔴 Mission 1: The Lost Signal
1. **Stage 1 (Leave Habitat):** Exit the pressurized Ares-1 airlock into the Martian environment.
2. **Stage 2 (Retrieve Power Coupler):** Locate the exterior emergency supply crate south of the habitat and press **`[E]`**.
3. **Stage 3 (Board Rover):** Walk to the rover parking depot, press **`[E]`** to board, and steer through the central basalt boulder canyon.
4. **Stage 4 (Repair Relay Tower):** Approach the ridge relay, exit the rover, and hold **`[E]`** to complete the repair sequence.
5. **Stage 5 (Storm Evacuation):** Race back to Ares-1 before the force-8 dust storm engulfs the sector.
6. **Ending Cliffhanger:** Restored telemetry intercepts an unidentified repeating narrowband signal echoing from deep within the crater floor:  
   *“Signal recovered. But we are not alone out here…”*

### 🔵 Mission 2: The Anomaly (Act II)
1. **Stage 1 (Canyon Transit):** Depart Ares Base northeast into the rugged alluvial canyon of Neretva Vallis. Track the acoustic signal using the rover's **RIMFAX ground-penetrating radar** HUD meter.
2. **Stage 2 (Deploy Seismic Beacons):**
   - Anchor **Seismic Beacon Alpha** at the geological fault point `(1050, 950)`.
   - Anchor **Seismic Beacon Beta** on the northern ridge `(1550, 500)` to triangulate the anomaly epicenter.
3. **Stage 3 (Enter Lava Tube):** Locate the collapsed basalt skylight at `(1750, 950)`. Press **`[E]`** to descend into the pitch-black subterranean cavern.
4. **Stage 4 (Sample Extraction):** Locate the relic at `(2350, 1650)`—an unrecorded 1990s deep-crust penetrator probe reactivated by the relay's carrier beam. Deploy the **rotary percussive coring drill** to secure a core sample in Titanium Tube #14.
5. **Stage 5 (Seismic Evacuation):** Coring triggers a magnitude 4.8 crustal Marsquake! With falling stalactites, ceiling dust, and violent tremors, race back to the surface portal before the lava tube roof collapses.
6. **Act II Debrief:** Secure the core sample, debrief with Houston Capcom Director Chen, and view full expedition statistics.

---

## ⚙️ Game Rules & Survival Mechanics

All calculations use delta time (`dt = delta / 1000`):

- **Oxygen:**
  - Standard outdoor consumption: `0.16%/s`.
  - Dust storm consumption (Mission 1): `0.30%/s`.
  - Airlock replenishment: `+35%/s` up to 100% inside the safe habitat ring.
- **Rover Battery:**
  - Flat terrain driving drain: `0.20%/s`.
  - Rough sand dunes drain: `0.40%/s`.
  - Stationary idle: `0.00%/s`.
  - Coring drill & relay repair costs: `-5.0%`.
- **Rover Integrity:**
  - Starting integrity: `100%`.
  - Rock & stalactite collisions: `-10%` per hard impact with camera shake and sparks.
  - If condition drops to `0%`, vehicle is permanently disabled, requiring completion on foot!
- **RIMFAX Signal Strength (Mission 2):**
  - Dynamically calculates distance to target waypoints (`15%` to `100%`).
  - Synthesizes periodic acoustic sonar pings that increase in frequency and pitch as you approach objectives.

---

## ⌨️ Controls Reference

| Control | Action |
|---|---|
| **`W`, `A`, `S`, `D` / Arrow Keys** | Walk astronaut & steer rover (acceleration, braking, reverse) |
| **`[E]`** | Interact (retrieve coupler, board/exit rover, repair relay, anchor beacons, deploy drill) |
| **`[SPACE]` or `[ENTER]`** | Advance radio dialogue or fast-forward text |
| **`[M]`** | Open NASA Planetary Science Field Guide |
| **`[ESC]`** | Open Pause Menu & Controls |
| **Speaker Icon (Top-Right)** | Mute / Unmute procedural Web Audio synthesizer |

---

## 🔬 Authentic NASA Science & Field Guide Entries

Every educational card references genuine NASA mission data and photographs:

1. **Jezero Crater & Ancient Lake Delta** (`PIA25673`) — Paleolake sediments & microbial habitability.
2. **In-Situ Equipment Maintenance** (`PIA24542`) — Modular parts and extreme Martian logistics.
3. **Deep Space Network & Relay Orbiters** (`PIA13559`) — MRO & MAVEN satellite links and 5-20 min light lag.
4. **Martian Dust Storms** (`PIA22329`) — Fine abrasive dust, electrostatic charges, and solar blackout hazards.
5. **RIMFAX Subsurface Radar Sounding** (`PIA24048`) — Ground-penetrating radar imaging rock strata down to 10+ meters.
6. **Neretva Vallis Ancient Megafloods** (`PIA26335`) — Catastrophic river valley inflow channel breaching Jezero rim.
7. **Martian Lava Tubes & Caves** (`PIA13387`) — Underground basalt shelters offering absolute radiation protection.
8. **Hermetic Sample Caching** (`PIA24808`) — Perseverance's 43 titanium sample tubes cached for Mars Sample Return.

---

## 🛠️ Technology Stack

- **Game Engine:** Phaser 3 (Arcade Physics, multi-scene management, procedural pixel/vector texture generator, dynamic particle emitters).
- **Frontend:** React 19 + TypeScript + Vite + Tailwind CSS.
- **Audio Synthesizer:** Zero-dependency procedural Web Audio API engine (engine pitch, footsteps, collision clangs, sonar pings, coring drill vibration, seismic rumbles, radio beeps, GTA-style brass stingers).
- **Architecture:** 100% client-side browser application.

---

## 📦 How to Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Launch Vite dev server
npm run dev

# 3. Open in browser at http://localhost:3000
```
